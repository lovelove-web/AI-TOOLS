"""Synthetic-traffic tests: every attack class must raise the expected rule."""
import time

import pytest
from scapy.all import ARP, DNS, DNSQR, ICMP, IP, TCP, UDP, Ether, Raw

from nids import protocols
from nids.alerts import AlertManager
from nids.config import Config
from nids.detect.auth import BruteForceDetector
from nids.detect.c2 import DnsDetector
from nids.detect.flood import FloodDetector
from nids.detect.scan import ScanDetector
from nids.detect.scan_tcp import TcpScanDetector
from nids.detect.signatures import SignatureDetector
from nids.packets import decode

ATK, VIC = "192.168.40.130", "192.168.40.129"
# Fixed MACs: a bare Ether() makes scapy resolve the local interface per packet (very slow).
FRAME = Ether(src="00:11:22:33:44:55", dst="00:aa:bb:cc:dd:ee")


def run(detector, packets):
    ids, t = set(), time.time()
    for i, pkt in enumerate(packets):
        pkt.time = t + i * 0.01
        info = decode(FRAME / pkt)
        protocols.identify(info)
        ids |= {a.rule_id for a in detector.process(info)}
    return ids


@pytest.fixture
def cfg():
    return Config()


def syn(port, flags="S"):
    return IP(src=ATK, dst=VIC) / TCP(sport=40000, dport=port, flags=flags)


def test_syn_scan(cfg):
    assert "SCN-001" in run(TcpScanDetector(cfg), [syn(p) for p in range(1, 30)])


@pytest.mark.parametrize("flags,rule", [("", "SCN-002"), ("FPU", "SCN-003"), ("F", "SCN-009")])
def test_stealth_scans(cfg, flags, rule):
    assert rule in run(TcpScanDetector(cfg), [syn(80, flags)])


def test_ping(cfg):
    assert "SCN-005" in run(ScanDetector(cfg), [IP(src=ATK, dst=VIC) / ICMP()])


def test_ping_sweep(cfg):
    pk = [IP(src=ATK, dst=f"192.168.40.{i}") / ICMP() for i in range(1, 10)]
    assert "SCN-006" in run(ScanDetector(cfg), pk)


def test_syn_flood(cfg):
    assert "DOS-001" in run(FloodDetector(cfg), [syn(80) for _ in range(300)])


def test_ssh_bruteforce(cfg):
    assert "BRT-001" in run(BruteForceDetector(cfg), [syn(22) for _ in range(15)])


def test_sql_injection(cfg):
    req = b"GET /item?id=1' UNION SELECT user,pass FROM users-- HTTP/1.1\r\nHost: x\r\n\r\n"
    assert "WEB-001" in run(SignatureDetector(cfg), [IP(src=ATK, dst=VIC) / TCP(dport=80) / Raw(req)])


def test_scanner_user_agent(cfg):
    req = b"GET / HTTP/1.1\r\nHost: x\r\nUser-Agent: sqlmap/1.7\r\n\r\n"
    assert "WEB-009" in run(SignatureDetector(cfg), [IP(src=ATK, dst=VIC) / TCP(dport=80) / Raw(req)])


def test_dns_tunnel(cfg):
    name = "aGVsbG93b3JsZGRhdGFleGZpbHRyYXRpb24xMjM0NTY3ODk.evil.com"
    pkt = IP(src=ATK, dst="8.8.8.8") / UDP(dport=53) / DNS(rd=1, qd=DNSQR(qname=name))
    assert "C2-001" in run(DnsDetector(cfg), [pkt])


def test_dedup_suppresses_repeats():
    seen = []
    mgr = AlertManager([seen.append])
    from nids.alerts import Alert
    from nids.constants import Severity
    for _ in range(5):
        mgr.raise_alert(Alert("X", "n", "c", Severity.LOW, "a", "b", "d"))
    assert len(seen) == 1 and mgr.suppressed == 4
