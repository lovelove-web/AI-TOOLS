"""Dashboard API: auth, roles, alert data, triage workflow, stats, health, exports."""
import urllib.error
import urllib.request

import pytest
from scapy.all import ICMP, IP

from conftest import ATK, VIC, attack, call, feed
from nids import reports, workflow


def test_requires_auth(env):
    _, base = env
    assert call(base, "/api/alerts")[0] == 401
    assert call(base, "/api/alerts", "wrong")[0] == 401
    assert call(base, "/api/alerts", "tok-view")[0] == 200


def test_roles_enforced(env):
    engine, base = env
    attack(engine)
    aid = call(base, "/api/alerts", "tok-view")[1]["alerts"][0]["id"]
    assert call(base, f"/api/alerts/{aid}", "tok-view", "POST", {"status": "resolved"})[0] == 403
    assert call(base, f"/api/alerts/{aid}", "tok-analyst", "POST", {"status": "resolved"})[0] == 200
    assert call(base, "/api/audit", "tok-analyst")[0] == 403
    assert call(base, "/api/audit", "tok-admin")[0] == 200
    assert call(base, "/api/rules/WEB-001", "tok-analyst", "POST", {"enabled": False})[0] == 403


def test_alert_has_ports_protocol_confidence_and_packet(env):
    engine, base = env
    attack(engine)
    alerts = call(base, "/api/alerts?severity=HIGH", "tok-view")[1]["alerts"]
    scan = next(a for a in alerts if a["rule_id"] == "SCN-001")
    assert scan["protocol"] == "TCP" and scan["confidence"] > 0 and scan["src"] == ATK
    detail = call(base, f"/api/alerts/{scan['id']}", "tok-view")[1]["alert"]
    assert detail["details"]["tcp_flags"] == "SYN" and detail["details"]["dst"] == VIC
    assert isinstance(detail["details"]["related"], list) and detail["details"]["related"]


def test_triage_workflow_and_notes(env):
    engine, base = env
    attack(engine)
    aid = call(base, "/api/alerts", "tok-view")[1]["alerts"][0]["id"]
    for status in ("acknowledged", "investigating", "resolved"):
        code, data, _ = call(base, f"/api/alerts/{aid}", "tok-analyst", "POST",
                             {"status": status, "note": f"moved to {status}"})
        assert code == 200 and data["alert"]["status"] == status
    assert len(data["alert"]["notes"]) == 3
    assert call(base, f"/api/alerts/{aid}", "tok-analyst", "POST", {"status": "bogus"})[0] == 400
    assert call(base, "/api/alerts?status=resolved", "tok-view")[1]["alerts"][0]["id"] == aid
    assert call(base, "/api/alerts/bulk", "tok-analyst", "POST", {"ids": [aid], "status": "new"})[1]["updated"] == 1


def test_severity_filter_and_summary(env):
    engine, base = env
    attack(engine)
    low = call(base, "/api/alerts?severity=LOW", "tok-view")[1]["alerts"]
    assert low and all(a["severity"] == "LOW" for a in low)
    summary = call(base, "/api/summary", "tok-view")[1]
    assert summary["severity"]["HIGH"] >= 1 and summary["open"] == summary["total"]
    assert summary["top_rules_all"]


def test_stats_endpoint(env):
    engine, base = env
    attack(engine)
    stats = call(base, "/api/stats", "tok-view")[1]
    assert stats["total_packets"] >= 30
    assert any(p["name"] == "TCP" for p in stats["protocols"])
    assert stats["top_talkers"][0]["ip"] == ATK and stats["top_ports"]


def test_exports(env):
    engine, base = env
    attack(engine)
    code, csv_body, hdr = call(base, "/api/export?format=csv", "tok-view")
    assert code == 200 and b"TCP port scan" in csv_body and "attachment" in hdr["Content-Disposition"]
    code, body, _ = call(base, "/api/export?format=json", "tok-view")
    assert code == 200 and body["count"] >= 1
    code, pdf, _ = call(base, "/api/export?format=pdf", "tok-view")
    assert code == 200 and pdf.startswith(b"%PDF-1.4") and pdf.rstrip().endswith(b"%%EOF")
    assert call(base, "/api/export?format=exe", "tok-view")[0] == 400


def test_csv_formula_injection_neutralised():
    row = {"id": 1, "ts": 0, "severity": "LOW", "name": '=HYPERLINK("http://evil")', "rule_id": "X"}
    assert b"'=HYPERLINK" in reports.to_csv([row])


def test_health_fields(env):
    engine, base = env
    attack(engine)
    h = call(base, "/api/health", "tok-view")[1]
    for key in ("monitoring", "packets_dropped", "drop_rate", "last_heartbeat", "worker_alive", "detectors_total"):
        assert key in h
    assert h["packets_analysed"] >= 30


def test_dedup_count_updates_in_db(env):
    engine, base = env
    # Detectors throttle themselves, so raise identical alerts straight into the manager.
    from nids.alerts import Alert
    from nids.constants import Severity
    for _ in range(3):
        engine._admit(Alert("TST-001", "Test alert", "test", Severity.LOW, ATK, VIC, "repeat"))
    row = call(base, "/api/alerts?q=TST-001", "tok-view")[1]["alerts"][0]
    assert row["count"] == 3 and engine.alerts.suppressed == 2


def test_query_limits_and_sql_injection_safe(env):
    engine, _ = env
    attack(engine)
    assert len(workflow.query_alerts(engine.db, limit=10_000)) <= 500
    assert workflow.query_alerts(engine.db, text="'; DROP TABLE alerts;--") == []
    assert engine.db.query("SELECT COUNT(*) c FROM alerts")[0]["c"] > 0


def test_static_and_path_traversal(env):
    _, base = env
    code, body, hdr = call(base, "/")
    assert code == 200 and b"NIDS Console" in body
    assert "frame-ancestors" in hdr["Content-Security-Policy"] or hdr["X-Frame-Options"] == "DENY"
    assert call(base, "/%2e%2e/%2e%2e/config.py")[0] == 404
    assert call(base, "/..%5c..%5cnids%5cconfig.py")[0] == 404


def test_host_header_rejected(env):
    _, base = env
    req = urllib.request.Request(base + "/", headers={"Host": "evil.example"})
    with pytest.raises(urllib.error.HTTPError) as err:
        urllib.request.urlopen(req)
    assert err.value.code == 403
