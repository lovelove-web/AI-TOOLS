"""Rule management, detector toggles, thresholds, and start/stop control."""
from scapy.all import IP, TCP, Raw

from conftest import ATK, VIC, attack, call, feed


def alert_ids(base):
    return {a["rule_id"] for a in call(base, "/api/alerts", "tok-view")[1]["alerts"]}


def test_disable_rule_suppresses_alerts(env):
    engine, base = env
    assert call(base, "/api/rules/SCN-001", "tok-admin", "POST", {"enabled": False})[0] == 200
    attack(engine)
    ids = alert_ids(base)
    assert "SCN-001" not in ids and "SCN-005" in ids


def test_severity_override(env):
    engine, base = env
    assert call(base, "/api/rules/SCN-005", "tok-admin", "POST", {"severity": "CRITICAL"})[0] == 200
    assert call(base, "/api/rules/SCN-005", "tok-admin", "POST", {"severity": "WRONG"})[0] == 400
    attack(engine)
    ping = next(a for a in call(base, "/api/alerts", "tok-view")[1]["alerts"] if a["rule_id"] == "SCN-005")
    assert ping["severity"] == "CRITICAL"


def test_detector_toggle_and_thresholds(env):
    engine, base = env
    assert call(base, "/api/detectors/scan", "tok-admin", "POST", {"enabled": False})[0] == 200
    attack(engine)
    assert "SCN-005" not in alert_ids(base)               # ping detector (scan) is off
    assert call(base, "/api/detectors/nope", "tok-admin", "POST", {"enabled": False})[0] == 404
    assert call(base, "/api/thresholds/scan_ports", "tok-admin", "POST", {"value": 5})[0] == 200
    assert engine.cfg.thresholds["scan_ports"] == 5
    assert call(base, "/api/thresholds/scan_ports", "tok-admin", "POST", {"reset": True})[0] == 200
    assert engine.cfg.thresholds["scan_ports"] == 15
    assert call(base, "/api/thresholds/nope", "tok-admin", "POST", {"value": 5})[0] == 404
    assert call(base, "/api/thresholds/scan_ports", "tok-admin", "POST", {"value": -1})[0] == 400


def test_custom_rule_lifecycle(env):
    engine, base = env
    good = {"rule_id": "CUS-001", "name": "Secret file", "pattern": "(?i)secret\\.txt",
            "severity": "HIGH", "target": "payload"}
    assert call(base, "/api/rules", "tok-admin", "POST", good)[0] == 200
    assert call(base, "/api/rules", "tok-admin", "POST", {**good, "pattern": "([unclosed"})[0] == 400
    assert call(base, "/api/rules", "tok-admin", "POST", {**good, "rule_id": "WEB-001"})[0] == 400
    feed(engine, [IP(src=ATK, dst=VIC) / TCP(dport=8000, flags="PA") / Raw(b"GET /Secret.txt")])
    assert "CUS-001" in alert_ids(base)
    assert any(r["rule_id"] == "CUS-001" and r["custom"] for r in call(base, "/api/rules", "tok-view")[1]["rules"])
    assert call(base, "/api/rules/CUS-001", "tok-admin", "DELETE")[0] == 200
    assert call(base, "/api/rules/WEB-001", "tok-admin", "DELETE")[0] == 400


def test_overrides_survive_restart(env, tmp_path):
    engine, base = env
    call(base, "/api/rules/WEB-001", "tok-admin", "POST", {"enabled": False})
    call(base, "/api/thresholds/scan_ports", "tok-admin", "POST", {"value": 7})
    from nids.config import Config
    from nids.engine import Engine
    again = Engine(Config(db_file=engine.cfg.db_file, log_dir=engine.cfg.log_dir, pcap_evidence=False), quiet=True)
    assert again.rules.is_disabled("WEB-001") and again.cfg.thresholds["scan_ports"] == 7
    again.db.close()


def test_monitor_start_bad_interface_reports_error(env):
    _, base = env
    code, data, _ = call(base, "/api/monitor/start", "tok-analyst", "POST", {"interfaces": ["no-such-nic"]})
    assert code == 409 and "not found" in data["error"]
    assert call(base, "/api/monitor/start", "tok-view", "POST", {})[0] == 403
    assert call(base, "/api/health", "tok-view")[1]["monitoring"] is False
    assert call(base, "/api/monitor/stop", "tok-analyst", "POST", {})[0] == 200
