"""Shared fixtures: a real engine + real HTTP server fed with synthetic attack traffic."""
import json
import threading
import time
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

import pytest
from scapy.all import ICMP, IP, TCP, Ether

from nids.config import Config
from nids.engine import Engine
from nids.web.actions import ActionApi
from nids.web.server import make_handler

ATK, VIC = "192.168.40.130", "192.168.40.129"
# Fixed MACs: a bare Ether() makes scapy resolve the local interface per packet (very slow).
FRAME = Ether(src="00:11:22:33:44:55", dst="00:aa:bb:cc:dd:ee")
TOKENS = {"tok-view": "viewer", "tok-analyst": "analyst", "tok-admin": "admin"}


def feed(engine, packets):
    t = time.time()
    for i, pkt in enumerate(packets):
        raw = FRAME / pkt
        raw.time = t + i * 0.01
        engine.handle_packet(raw)


def attack(engine):
    """A port scan plus a ping from the Kali VM."""
    feed(engine, [IP(src=ATK, dst=VIC) / TCP(sport=4444, dport=p, flags="S") for p in range(1, 30)])
    feed(engine, [IP(src=ATK, dst=VIC) / ICMP()])


def call(base, path, token=None, method="GET", body=None):
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(base + path, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            raw = r.read()
            return r.status, (json.loads(raw) if "json" in r.headers["Content-Type"] else raw), r.headers
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}"), e.headers


@pytest.fixture
def env(tmp_path):
    cfg = Config(db_file=str(tmp_path / "t.db"), log_dir=str(tmp_path / "logs"), pcap_evidence=False)
    engine = Engine(cfg, quiet=True)
    server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(ActionApi(engine), TOKENS, {"127.0.0.1"}))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    yield engine, f"http://127.0.0.1:{server.server_port}"
    server.shutdown()
    engine._stop.set()
    engine.db.close()
