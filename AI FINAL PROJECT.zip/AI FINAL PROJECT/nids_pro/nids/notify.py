"""Alert sinks: console, JSON log, database, Slack/Teams/webhook, email, syslog, PCAP evidence."""
from __future__ import annotations

import json
import smtplib
import socket
import urllib.request
from email.message import EmailMessage

from .alerts import Alert
from .constants import Severity

COLOURS = {Severity.INFO: "\033[37m", Severity.LOW: "\033[36m", Severity.MEDIUM: "\033[33m",
           Severity.HIGH: "\033[31m", Severity.CRITICAL: "\033[1;41m"}
RESET = "\033[0m"


def console_sink(alert: Alert) -> None:
    import time
    t = time.strftime("%H:%M:%S", time.localtime(alert.ts))
    print(f"{COLOURS[alert.severity]}{t} {alert.headline()}{RESET}")
    if alert.mitre:
        print(f"         MITRE ATT&CK: {alert.mitre}")
    if alert.evidence:
        print(f"         Evidence: {json.dumps(alert.evidence, default=str)[:300]}")


def _post_json(url: str, payload: dict, headers: dict | None = None) -> None:
    req = urllib.request.Request(url, json.dumps(payload).encode(),
                                 {"Content-Type": "application/json", **(headers or {})})
    urllib.request.urlopen(req, timeout=5).read()


class Notifier:
    """Sends alerts at or above a minimum severity to configured channels."""

    def __init__(self, cfg: dict, min_severity: Severity):
        self.cfg = cfg
        self.min = min_severity

    def __call__(self, alert: Alert) -> None:
        if alert.severity < self.min:
            return
        text = alert.headline()
        c = self.cfg
        if c.get("slack_webhook"):
            _post_json(c["slack_webhook"], {"text": text})
        if c.get("teams_webhook"):
            _post_json(c["teams_webhook"], {"text": text})
        if c.get("webhook"):                       # generic API/SOAR/ticketing webhook
            _post_json(c["webhook"], alert.to_dict(), c.get("webhook_headers"))
        if c.get("sms_webhook"):                   # e.g. Twilio-compatible gateway
            _post_json(c["sms_webhook"], {"message": text[:160]})
        if c.get("email"):
            e = c["email"]
            msg = EmailMessage()
            msg["Subject"], msg["From"], msg["To"] = f"NIDS: {alert.name}", e["from"], e["to"]
            msg.set_content(text + "\n\n" + json.dumps(alert.to_dict(), indent=2, default=str))
            with smtplib.SMTP(e["host"], e.get("port", 25), timeout=10) as s:
                if e.get("starttls"):
                    s.starttls()
                if e.get("user"):
                    s.login(e["user"], e["password"])
                s.send_message(msg)
        if c.get("syslog"):                        # SIEM integration, CEF over UDP
            host, port = c["syslog"]["host"], c["syslog"].get("port", 514)
            cef = (f"CEF:0|NIDS|nids|1.0|{alert.rule_id}|{alert.name}|{int(alert.severity) * 2 + 1}|"
                   f"src={alert.src} dst={alert.dst} msg={alert.description}")
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.sendto(cef.encode(), (host, port))
