"""Alert model, deduplication, correlation and dispatch."""
from __future__ import annotations

import time
from collections import defaultdict, deque
from dataclasses import dataclass, field, fields

from .constants import (CORRELATION_MIN_CATEGORIES, CORRELATION_WINDOW,
                        DEDUP_COOLDOWN, Severity)


@dataclass
class Alert:
    rule_id: str
    name: str
    category: str
    severity: Severity
    src: str
    dst: str
    description: str
    mitre: str = ""
    evidence: dict = field(default_factory=dict)
    ts: float = field(default_factory=time.time)
    count: int = 1
    sport: int = 0
    dport: int = 0
    protocol: str = ""
    confidence: float | None = None
    details: dict = field(default_factory=dict)   # decoded triggering packet + related packets
    db_id: int | None = None
    packet: object = None   # scapy packet kept for PCAP evidence (never serialised)

    def to_dict(self) -> dict:
        data = {f.name: getattr(self, f.name) for f in fields(self) if f.name != "packet"}
        data["severity"] = self.severity.name
        return data

    def headline(self) -> str:
        return (f"[{self.severity.name}] {self.name} ({self.rule_id}) "
                f"{self.src} -> {self.dst}: {self.description}")


class AlertManager:
    """Deduplicates repeated alerts and correlates multi-stage attacks."""

    def __init__(self, sinks, cooldown: int = DEDUP_COOLDOWN, on_repeat=None):
        self.sinks = sinks            # callables taking an Alert
        self.cooldown = cooldown
        self.on_repeat = on_repeat    # called with the original alert when a duplicate is suppressed
        self._last: dict[tuple, Alert] = {}
        self._history: dict[str, deque] = defaultdict(deque)
        self._correlated: dict[str, float] = {}
        self.total = 0
        self.suppressed = 0

    def raise_alert(self, alert: Alert) -> None:
        key = (alert.rule_id, alert.src, alert.dst)
        prev = self._last.get(key)
        if prev and alert.ts - prev.ts < self.cooldown:
            prev.count += 1
            self.suppressed += 1
            if self.on_repeat:
                self.on_repeat(prev)
            return
        self._last[key] = alert
        self.total += 1
        self._dispatch(alert)
        self._correlate(alert)

    def _dispatch(self, alert: Alert) -> None:
        for sink in self.sinks:
            try:
                sink(alert)
            except Exception as exc:  # a broken sink must never stop detection
                print(f"[!] alert sink {getattr(sink, '__name__', sink)} failed: {exc}")

    def _correlate(self, alert: Alert) -> None:
        if alert.category == "correlation":
            return
        hist = self._history[alert.src]
        hist.append((alert.ts, alert.category, alert.name))
        while hist and alert.ts - hist[0][0] > CORRELATION_WINDOW:
            hist.popleft()
        cats = {c for _, c, _ in hist}
        if len(cats) >= CORRELATION_MIN_CATEGORIES and \
                alert.ts - self._correlated.get(alert.src, 0) > CORRELATION_WINDOW:
            self._correlated[alert.src] = alert.ts
            steps = " -> ".join(dict.fromkeys(n for _, _, n in hist))
            self._dispatch(Alert(
                "COR-001", "Multi-stage attack campaign", "correlation", Severity.CRITICAL,
                alert.src, alert.dst,
                f"Host {alert.src} triggered {len(cats)} different attack categories "
                f"within {CORRELATION_WINDOW}s: {steps}",
                mitre="TA0043/TA0001", evidence={"steps": steps, "categories": sorted(cats)},
                ts=alert.ts, confidence=0.95, protocol="multi"))
