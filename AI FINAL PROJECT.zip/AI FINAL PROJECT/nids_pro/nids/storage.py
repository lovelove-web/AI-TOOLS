"""SQLite persistence (models, alerts, assets, audit, pending actions) + JSON-lines logs."""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS models (
    id INTEGER PRIMARY KEY AUTOINCREMENT, model_name TEXT NOT NULL, accuracy REAL,
    feature_names TEXT NOT NULL, model_blob BLOB NOT NULL, scaler_blob BLOB NOT NULL,
    created_at TEXT NOT NULL, is_active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL NOT NULL, rule_id TEXT, name TEXT,
    category TEXT, severity TEXT, src TEXT, dst TEXT, description TEXT, mitre TEXT,
    evidence TEXT, count INTEGER DEFAULT 1, status TEXT DEFAULT 'new');
CREATE INDEX IF NOT EXISTS idx_alerts_ts ON alerts(ts);
CREATE TABLE IF NOT EXISTS assets (
    ip TEXT PRIMARY KEY, mac TEXT, first_seen REAL, last_seen REAL, services TEXT);
CREATE TABLE IF NOT EXISTS audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, actor TEXT, action TEXT, detail TEXT);
CREATE TABLE IF NOT EXISTS actions (
    id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, ip TEXT, action TEXT, reason TEXT,
    status TEXT DEFAULT 'pending', decided_by TEXT);
CREATE TABLE IF NOT EXISTS health (ts REAL, packets INTEGER, alerts INTEGER, flows INTEGER, dropped INTEGER);
CREATE TABLE IF NOT EXISTS rule_overrides (
    rule_id TEXT PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 1, severity TEXT, updated_at REAL);
CREATE TABLE IF NOT EXISTS custom_rules (
    rule_id TEXT PRIMARY KEY, name TEXT, category TEXT, severity TEXT, pattern TEXT,
    target TEXT, mitre TEXT, enabled INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS threshold_overrides (key TEXT PRIMARY KEY, value REAL NOT NULL);
"""

# Columns added after v2.0 -- applied to databases created by older versions.
ALERT_MIGRATIONS = {
    "sport": "INTEGER DEFAULT 0", "dport": "INTEGER DEFAULT 0", "protocol": "TEXT DEFAULT ''",
    "confidence": "REAL", "details": "TEXT DEFAULT '{}'", "notes": "TEXT DEFAULT '[]'",
    "updated_at": "REAL", "updated_by": "TEXT",
}


class Database:
    def __init__(self, path: str):
        self.path = path
        self._lock = threading.Lock()
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        existing = {r["name"] for r in self.conn.execute("PRAGMA table_info(alerts)")}
        for column, ddl in ALERT_MIGRATIONS.items():
            if column not in existing:
                self.conn.execute(f"ALTER TABLE alerts ADD COLUMN {column} {ddl}")
        self.conn.execute("CREATE INDEX IF NOT EXISTS idx_alerts_status ON alerts(status)")
        self.conn.commit()

    def execute(self, sql: str, params=()):
        with self._lock:
            cur = self.conn.execute(sql, params)
            self.conn.commit()
            return cur

    def query(self, sql: str, params=()) -> list[dict]:
        with self._lock:
            return [dict(r) for r in self.conn.execute(sql, params).fetchall()]

    def save_alert(self, a) -> int:
        cur = self.execute(
            "INSERT INTO alerts (ts, rule_id, name, category, severity, src, dst, description,"
            " mitre, evidence, count, sport, dport, protocol, confidence, details)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (a.ts, a.rule_id, a.name, a.category, a.severity.name, a.src, a.dst,
             a.description, a.mitre, json.dumps(a.evidence, default=str), a.count,
             a.sport, a.dport, a.protocol, a.confidence, json.dumps(a.details, default=str)))
        a.db_id = cur.lastrowid
        return a.db_id

    def audit(self, actor: str, action: str, detail: str = "") -> None:
        self.execute("INSERT INTO audit (ts, actor, action, detail) VALUES (?,?,?,?)",
                     (time.time(), actor, action, detail))

    def upsert_asset(self, ip: str, mac: str, service: str | None) -> None:
        row = self.query("SELECT services FROM assets WHERE ip=?", (ip,))
        now = time.time()
        if not row:
            self.execute("INSERT INTO assets VALUES (?,?,?,?,?)",
                         (ip, mac, now, now, json.dumps([service] if service else [])))
            return
        services = set(json.loads(row[0]["services"] or "[]"))
        if service:
            services.add(service)
        self.execute("UPDATE assets SET last_seen=?, mac=COALESCE(NULLIF(?, ''), mac), services=? WHERE ip=?",
                     (now, mac, json.dumps(sorted(services)), ip))

    def close(self) -> None:
        self.conn.close()


class JsonLogs:
    """Structured JSON-lines logs: alerts, flows, dns, http, tls, files, ..."""

    def __init__(self, directory: str):
        self.dir = Path(directory)
        self.dir.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def write(self, stream: str, record: dict) -> None:
        record = {"timestamp": time.strftime("%Y-%m-%dT%H:%M:%S%z"), **record}
        with self._lock, open(self.dir / f"{stream}.jsonl", "a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, default=str) + "\n")
