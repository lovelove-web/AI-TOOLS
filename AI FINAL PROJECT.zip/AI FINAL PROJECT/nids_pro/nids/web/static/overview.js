/* Overview tab: summary cards, timeline, attack-type widgets, latest alerts, top tables. */
NIDS.overview = (function () {
  const card = (cls, num, lbl, extra) =>
    `<div class="card ${cls} ${extra || ""}"><div class="num">${num}</div><div class="lbl">${lbl}</div></div>`;

  function cards(sum, health) {
    const sev = sum.severity || {};
    const state = health.monitoring ? "ok" : "";
    document.getElementById("cards").innerHTML =
      card(state, health.monitoring ? "ACTIVE" : "STOPPED", "Monitoring") +
      NIDS.SEVERITIES.map(s => `<div class="card ${s} clickable" data-sev="${s}"><div class="num">${sev[s] || 0}</div>
        <div class="lbl">${s} alerts</div></div>`).join("") +
      card("", NIDS.fmtNum(sum.open), "Open (unresolved)") +
      card("", NIDS.fmtNum(health.packets_analysed), "Packets analysed");
  }

  function widgets(rows) {
    const html = NIDS.WIDGETS.map(w => {
      const hits = rows.filter(w.match);
      const total = hits.reduce((s, r) => s + r.n, 0);
      const worst = hits.some(r => r.severity === "CRITICAL");
      return `<div class="widget ${worst ? "hot" : ""}" data-widget="${NIDS.esc(w.label)}">
        <div class="num">${w.icon} ${NIDS.fmtNum(total)}</div><div class="lbl">${NIDS.esc(w.label)}</div></div>`;
    }).join("");
    document.getElementById("attackWidgets").innerHTML = html;
  }

  function timeline(rows) {
    const byBucket = {};
    rows.forEach(r => { (byBucket[r.bucket] = byBucket[r.bucket] || {t: r.bucket})[r.severity] = r.n; });
    NIDS.charts.stacked(document.getElementById("chartTimeline"),
      Object.values(byBucket).sort((a, b) => a.t - b.t));
  }

  function tops(sum) {
    const sevRank = {CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1, INFO: 0};
    const table = (title, rows, key, extra) => `<h3 style="margin-top:6px">${title}</h3>` + (rows.length ?
      "<table><tbody>" + rows.map(r => `<tr class="row" data-q="${NIDS.esc(r[key])}"><td class="mono">${NIDS.esc(r[key])}</td>
        <td style="text-align:right"><b>${r.n}</b> alerts</td>${extra ? `<td>${NIDS.sevBadge(extra(r))}</td>` : ""}</tr>`).join("") +
      "</tbody></table>" : '<div class="muted">None yet</div>');
    document.getElementById("topTables").innerHTML =
      table("Top attackers", sum.top_sources, "src", r => r.worst || "LOW") + table("Most targeted hosts", sum.top_targets, "dst");
    void sevRank;
  }

  async function refresh(health) {
    const [sum, latest] = await Promise.all([NIDS.get("/api/summary"), NIDS.get("/api/alerts?limit=8")]);
    cards(sum, health);
    widgets(sum.top_rules_all || []);
    timeline(sum.timeline);
    tops(sum);
    document.getElementById("latestTable").innerHTML = NIDS.alerts.table(latest.alerts);
  }

  function init() {
    document.getElementById("cards").addEventListener("click", e => {
      const c = e.target.closest("[data-sev]"); if (!c) return;
      NIDS.alerts.filterBy([c.dataset.sev]); NIDS.showTab("alerts");
    });
    document.getElementById("latestTable").addEventListener("click", e => {
      const tr = e.target.closest("tr.row"); if (tr) NIDS.drawer.open(Number(tr.dataset.id));
    });
    document.getElementById("topTables").addEventListener("click", e => {
      const tr = e.target.closest("tr[data-q]"); if (!tr) return;
      NIDS.alerts.setText(tr.dataset.q); NIDS.showTab("alerts");
    });
    document.getElementById("attackWidgets").addEventListener("click", e => {
      const w = e.target.closest("[data-widget]"); if (!w) return;
      NIDS.alerts.setText(""); NIDS.showTab("alerts");
    });
  }

  return {init, refresh};
})();
