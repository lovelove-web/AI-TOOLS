/* Admin tab: IPS approval queue, asset inventory, audit trail. */
NIDS.admin = (function () {
  const empty = msg => `<div class="empty">${msg}</div>`;

  function actions(list) {
    if (!list.length) return empty("No response actions queued. (Run in IPS mode to propose blocks.)");
    const admin = NIDS.role === "admin";
    return `<table><thead><tr><th>Time</th><th>IP</th><th>Action</th><th>Reason</th><th>Status</th><th></th></tr></thead><tbody>` +
      list.map(a => `<tr><td>${NIDS.fmtTime(a.ts)}</td><td class="mono">${NIDS.esc(a.ip)}</td><td>${NIDS.esc(a.action)}</td>
        <td>${NIDS.esc(a.reason)}</td><td>${NIDS.statusBadge(a.status)}</td>
        <td>${a.status === "pending" && admin ? `<button class="btn small primary" data-act="${a.id}" data-v="approve">Approve</button>
        <button class="btn small" data-act="${a.id}" data-v="reject">Reject</button>` : ""}</td></tr>`).join("") + "</tbody></table>";
  }

  const assets = list => !list.length ? empty("No assets discovered yet") :
    `<table><thead><tr><th>IP</th><th>MAC</th><th>Services</th><th>Last seen</th></tr></thead><tbody>` +
    list.map(a => `<tr><td class="mono">${NIDS.esc(a.ip)}</td><td class="mono">${NIDS.esc(a.mac)}</td>
      <td>${NIDS.esc(JSON.parse(a.services || "[]").join(", "))}</td><td>${NIDS.ago(a.last_seen)}</td></tr>`).join("") + "</tbody></table>";

  const audit = list => !list.length ? empty("Audit log is empty") :
    `<table><thead><tr><th>Time</th><th>Actor</th><th>Action</th><th>Detail</th></tr></thead><tbody>` +
    list.map(a => `<tr><td>${NIDS.fmtDateTime(a.ts)}</td><td>${NIDS.esc(a.actor)}</td><td>${NIDS.esc(a.action)}</td>
      <td class="muted">${NIDS.esc(a.detail)}</td></tr>`).join("") + "</tbody></table>";

  async function refresh() {
    const jobs = [NIDS.get("/api/actions"), NIDS.get("/api/assets")];
    if (NIDS.role === "admin") jobs.push(NIDS.get("/api/audit"));
    const [a, s, l] = await Promise.all(jobs);
    document.getElementById("actionsTable").innerHTML = actions(a.actions);
    document.getElementById("assetsTable").innerHTML = assets(s.assets);
    document.getElementById("auditTable").innerHTML = l ? audit(l.audit) : empty("Audit trail is visible to admins only");
  }

  function init() {
    document.getElementById("actionsTable").addEventListener("click", async e => {
      const id = e.target.dataset.act; if (!id) return;
      try {
        const r = await NIDS.post(`/api/actions/${id}/${e.target.dataset.v}`);
        NIDS.toast(r.result); refresh();
      } catch (err) { NIDS.toast(err.message, true); }
    });
  }

  return {init, refresh};
})();
