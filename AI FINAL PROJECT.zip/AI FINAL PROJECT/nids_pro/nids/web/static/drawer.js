/* Alert drill-down drawer: packet details, related events and the triage workflow. */
NIDS.drawer = (function () {
  const el = () => document.getElementById("drawer");
  const body = () => document.getElementById("drawerBody");
  let current = null;

  function notesHtml(a) {
    return (a.notes || []).map(n => `<div class="note"><b>${NIDS.esc(n.by)}</b>
      <span class="muted">${NIDS.fmtDateTime(n.ts)} &middot; ${NIDS.esc(n.status)}</span><br>${NIDS.esc(n.text)}</div>`).join("")
      || '<div class="muted">No notes yet.</div>';
  }

  function relatedAlertsHtml(list) {
    const rows = (list || []).map(r => `<tr class="row ${r.severity}" data-open="${r.id}"><td>${NIDS.fmtTime(r.ts)}</td>
      <td>${NIDS.sevBadge(r.severity)}</td><td>${NIDS.esc(r.name)}</td><td>${r.dport || "-"}</td>
      <td>${NIDS.statusBadge(r.status)}</td></tr>`).join("");
    return rows ? `<table><tbody>${rows}</tbody></table>` : '<div class="muted">None.</div>';
  }

  const RESPONSE_FORM = `<h3>Response</h3>
    <textarea id="noteBox" placeholder="Response notes (what you found / did)..." maxlength="1000"></textarea>
    <div class="actions-row">
      <button class="btn small" data-set="acknowledged">&#10003; Acknowledge</button>
      <button class="btn small" data-set="investigating">&#128269; Investigate</button>
      <button class="btn small primary" data-set="resolved">&#10004; Resolve</button>
      <button class="btn small ghost" data-set="">+ Add note only</button></div>`;

  function render(data) {
    const a = data.alert; current = a;
    const ev = Object.entries(a.evidence || {}).map(([k, v]) =>
      [k, `<span class="mono">${NIDS.esc(typeof v === "object" ? JSON.stringify(v) : v)}</span>`]);
    body().innerHTML = `
      <h2 style="margin:0 40px 4px 0">${NIDS.sevBadge(a.severity)} ${NIDS.esc(a.name)}</h2>
      <div class="muted">Alert #${a.id} &middot; ${NIDS.esc(a.rule_id)} &middot; ${NIDS.statusBadge(a.status)}</div>
      <p>${NIDS.esc(a.description)}</p>
      ${NIDS.view.kv([["Category", NIDS.esc(a.category)], ["MITRE ATT&amp;CK", NIDS.esc(a.mitre)],
        ["Confidence", NIDS.confBar(a.confidence)], ["Occurrences", a.count], ["First seen", NIDS.fmtDateTime(a.ts)]])}
      ${NIDS.role !== "viewer" ? RESPONSE_FORM : ""}
      <h3>Notes &amp; history</h3>${notesHtml(a)}
      <h3 style="margin-top:18px">Triggering packet</h3>${NIDS.view.packet(a.details)}
      <h3>Detection evidence</h3>${NIDS.view.kv(ev)}
      <h3>Related network events <small>(packets between these hosts)</small></h3>${NIDS.view.related((a.details || {}).related)}
      <h3 style="margin-top:18px">Other alerts from ${NIDS.esc(a.src)}</h3>${relatedAlertsHtml(data.related_alerts)}`;
  }

  async function open(id) {
    el().classList.remove("hidden");
    body().innerHTML = '<div class="empty">Loading...</div>';
    try { render(await NIDS.get("/api/alerts/" + id)); }
    catch (e) { body().innerHTML = `<div class="empty">${NIDS.esc(e.message)}</div>`; }
  }

  async function setStatus(status) {
    const note = document.getElementById("noteBox").value;
    if (!status && !note.trim()) return NIDS.toast("Write a note first", true);
    try {
      await NIDS.post("/api/alerts/" + current.id, {status: status || undefined, note});
      NIDS.toast(status ? "Alert marked " + status : "Note added");
      open(current.id); NIDS.alerts.refresh();
    } catch (e) { NIDS.toast(e.message, true); }
  }

  function close() { el().classList.add("hidden"); current = null; }

  function init() {
    document.getElementById("drawerClose").onclick = close;
    el().addEventListener("click", e => {
      if (e.target === el()) return close();
      if (e.target.dataset && "set" in e.target.dataset) setStatus(e.target.dataset.set);
      const r = e.target.closest("[data-open]"); if (r) open(Number(r.dataset.open));
    });
    document.addEventListener("keydown", e => { if (e.key === "Escape") close(); });
  }

  return {init, open, close};
})();
