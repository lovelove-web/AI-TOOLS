/* Tiny dependency-free canvas charts (works offline in an isolated lab). */
NIDS.charts = (function () {
  const GRID = "#25304d", TEXT = "#8d9ab8";
  const PALETTE = ["#6366f1", "#22c55e", "#f97316", "#3b82f6", "#eab308", "#ec4899", "#14b8a6", "#a855f7"];

  function setup(canvas) {
    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth, h = Number(canvas.getAttribute("height")) || 160;
    canvas.width = w * dpr; canvas.height = h * dpr; canvas.style.height = h + "px";
    const ctx = canvas.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    ctx.font = "11px Segoe UI, sans-serif";
    return {ctx, w, h};
  }

  function empty(ctx, w, h, msg) {
    ctx.fillStyle = TEXT; ctx.textAlign = "center";
    ctx.fillText(msg || "No data yet", w / 2, h / 2);
  }

  function axes(ctx, w, h, max, fmt, pad) {
    ctx.strokeStyle = GRID; ctx.fillStyle = TEXT; ctx.textAlign = "right"; ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = pad.t + (h - pad.t - pad.b) * i / 4;
      ctx.beginPath(); ctx.moveTo(pad.l, y); ctx.lineTo(w - pad.r, y); ctx.stroke();
      ctx.fillText(fmt(max * (1 - i / 4)), pad.l - 6, y + 4);
    }
  }

  /** Area/line chart. points = [{t, v}] */
  function line(canvas, points, color, fmt) {
    const {ctx, w, h} = setup(canvas);
    if (!points.length) return empty(ctx, w, h, "Waiting for traffic...");
    const pad = {l: 52, r: 10, t: 8, b: 20};
    const max = Math.max(1, ...points.map(p => p.v)) * 1.15;
    axes(ctx, w, h, max, fmt || (v => Math.round(v)), pad);
    const x = i => pad.l + (w - pad.l - pad.r) * (points.length === 1 ? 1 : i / (points.length - 1));
    const y = v => pad.t + (h - pad.t - pad.b) * (1 - v / max);
    ctx.beginPath();
    points.forEach((p, i) => i ? ctx.lineTo(x(i), y(p.v)) : ctx.moveTo(x(i), y(p.v)));
    ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.stroke();
    ctx.lineTo(x(points.length - 1), h - pad.b); ctx.lineTo(x(0), h - pad.b); ctx.closePath();
    ctx.fillStyle = color + "33"; ctx.fill();
    ctx.fillStyle = TEXT; ctx.textAlign = "center";
    [0, points.length - 1].forEach(i => ctx.fillText(NIDS.fmtTime(points[i].t), Math.min(Math.max(x(i), 40), w - 30), h - 4));
  }

  /** Stacked bars by severity. buckets = [{t, CRITICAL, HIGH, ...}] */
  function stacked(canvas, buckets) {
    const {ctx, w, h} = setup(canvas);
    if (!buckets.length) return empty(ctx, w, h, "No alerts in the last hour");
    const pad = {l: 34, r: 8, t: 8, b: 20};
    const totals = buckets.map(b => NIDS.SEVERITIES.reduce((s, k) => s + (b[k] || 0), 0));
    const max = Math.max(1, ...totals) * 1.15;
    axes(ctx, w, h, max, v => Math.round(v), pad);
    const bw = Math.max(3, Math.min(28, (w - pad.l - pad.r) / buckets.length - 3));
    buckets.forEach((b, i) => {
      const x = pad.l + (w - pad.l - pad.r) * (i + 0.5) / buckets.length - bw / 2;
      let base = h - pad.b;
      [...NIDS.SEVERITIES].reverse().forEach(k => {
        const hh = (h - pad.t - pad.b) * (b[k] || 0) / max;
        ctx.fillStyle = NIDS.SEV_COLORS[k]; ctx.fillRect(x, base - hh, bw, hh); base -= hh;
      });
    });
    ctx.fillStyle = TEXT; ctx.textAlign = "center";
    ctx.fillText(NIDS.fmtTime(buckets[0].t), pad.l + 14, h - 4);
    ctx.fillText(NIDS.fmtTime(buckets[buckets.length - 1].t), w - 30, h - 4);
  }

  /** Doughnut with legend. items = [{name, count}] */
  function doughnut(canvas, items) {
    const {ctx, w, h} = setup(canvas);
    const total = items.reduce((s, i) => s + i.count, 0);
    if (!total) return empty(ctx, w, h);
    const cx = Math.min(h / 2, w / 3), cy = h / 2, r = Math.min(cx, cy) - 8;
    let angle = -Math.PI / 2;
    items.forEach((it, i) => {
      const a = it.count / total * Math.PI * 2;
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, r, angle, angle + a); ctx.closePath();
      ctx.fillStyle = PALETTE[i % PALETTE.length]; ctx.fill(); angle += a;
    });
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.58, 0, Math.PI * 2); ctx.fillStyle = "#131a2e"; ctx.fill();
    ctx.textAlign = "left";
    items.forEach((it, i) => {
      const y = 18 + i * 20;
      ctx.fillStyle = PALETTE[i % PALETTE.length]; ctx.fillRect(cx * 2 + 16, y - 9, 10, 10);
      ctx.fillStyle = "#e6ebf5";
      ctx.fillText(`${it.name}  ${(it.count / total * 100).toFixed(1)}%`, cx * 2 + 32, y);
    });
  }

  return {line, stacked, doughnut};
})();

/** Horizontal bar list rendered as HTML (used for top talkers / ports). */
NIDS.barList = function (rows, labelFn, valueFn, fmt) {
  if (!rows.length) return '<div class="empty">No data yet</div>';
  const max = Math.max(...rows.map(valueFn)) || 1;
  return "<table>" + rows.map(r => `<tr><td class="mono">${NIDS.esc(labelFn(r))}</td>
    <td style="width:45%"><div class="bar"><i style="width:${valueFn(r) / max * 100}%"></i></div></td>
    <td style="text-align:right">${fmt(valueFn(r))}</td></tr>`).join("") + "</table>";
};
