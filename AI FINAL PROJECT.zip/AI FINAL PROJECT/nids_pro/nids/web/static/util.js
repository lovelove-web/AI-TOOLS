/* Shared helpers: API client, formatting, escaping, toast. Exposes the global NIDS namespace. */
const NIDS = {token: sessionStorage.getItem("nids_token") || "", role: "viewer", state: {}};

NIDS.SEV_COLORS = {CRITICAL: "#ef4444", HIGH: "#f97316", MEDIUM: "#eab308", LOW: "#3b82f6", INFO: "#64748b"};
NIDS.SEVERITIES = ["CRITICAL", "HIGH", "MEDIUM", "LOW"];

NIDS.esc = s => String(s ?? "").replace(/[&<>"']/g,
  c => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c]));

NIDS.api = async function (method, path, body) {
  const res = await fetch(path, {
    method,
    headers: {Authorization: "Bearer " + NIDS.token, ...(body ? {"Content-Type": "application/json"} : {})},
    body: body ? JSON.stringify(body) : undefined,
  });
  if (res.status === 401) { NIDS.logout(); throw new Error("Session expired"); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || res.statusText);
  return data;
};
NIDS.get = (path) => NIDS.api("GET", path);
NIDS.post = (path, body) => NIDS.api("POST", path, body || {});

NIDS.download = async function (path, fallbackName) {
  const res = await fetch(path, {headers: {Authorization: "Bearer " + NIDS.token}});
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || "export failed");
  const match = /filename="([^"]+)"/.exec(res.headers.get("Content-Disposition") || "");
  const url = URL.createObjectURL(await res.blob());
  const a = Object.assign(document.createElement("a"), {href: url, download: match ? match[1] : fallbackName});
  document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
};

NIDS.fmtTime = ts => ts ? new Date(ts * 1000).toLocaleTimeString([], {hour12: false}) : "-";
NIDS.fmtDateTime = ts => ts ? new Date(ts * 1000).toLocaleString([], {hour12: false}) : "-";
NIDS.fmtNum = n => Number(n || 0).toLocaleString();
NIDS.fmtBytes = function (b) {
  b = Number(b || 0);
  const units = ["B", "KB", "MB", "GB", "TB"];
  let i = 0;
  while (b >= 1024 && i < units.length - 1) { b /= 1024; i++; }
  return b.toFixed(i ? 1 : 0) + " " + units[i];
};
NIDS.fmtDuration = function (s) {
  s = Math.floor(s);
  const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60);
  return (d ? d + "d " : "") + (h || d ? h + "h " : "") + m + "m " + (s % 60) + "s";
};
NIDS.ago = function (ts) {
  const s = Math.max(0, Date.now() / 1000 - ts);
  return s < 60 ? Math.floor(s) + "s ago" : s < 3600 ? Math.floor(s / 60) + "m ago" : Math.floor(s / 3600) + "h ago";
};

NIDS.sevBadge = s => `<span class="sev ${NIDS.esc(s)}">${NIDS.esc(s)}</span>`;
NIDS.statusBadge = s => `<span class="st ${NIDS.esc(s)}">${NIDS.esc(s)}</span>`;
NIDS.confBar = function (c) {
  if (c === null || c === undefined) return '<span class="muted">n/a</span>';
  const pct = Math.round(c * 100);
  return `<div class="conf"><div class="bar"><i style="width:${pct}%"></i></div>${pct}%</div>`;
};

NIDS.toast = function (msg, isError) {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.className = "toast" + (isError ? " err" : "");
  clearTimeout(NIDS._toastTimer);
  NIDS._toastTimer = setTimeout(() => el.classList.add("hidden"), 4500);
};

/* Attack-type widgets: which rule-id prefixes / categories roll up into each tile. */
NIDS.WIDGETS = [
  {label: "Port scans", icon: "&#128269;", match: a => /^SCN-/.test(a.rule_id) || a.rule_id === "EXP-009"},
  {label: "Brute force", icon: "&#128273;", match: a => /^BRT-/.test(a.rule_id)},
  {label: "SYN flood", icon: "&#127754;", match: a => a.rule_id === "DOS-001"},
  {label: "DoS / DDoS", icon: "&#128165;", match: a => /^DOS-/.test(a.rule_id) && a.rule_id !== "DOS-001"},
  {label: "Malware / C2", icon: "&#128375;", match: a => /^(MAL|C2|TI)-/.test(a.rule_id)},
  {label: "Web attacks", icon: "&#127760;", match: a => /^WEB-/.test(a.rule_id)},
  {label: "Exploits / MITM", icon: "&#9888;", match: a => /^EXP-/.test(a.rule_id) && a.rule_id !== "EXP-009"},
  {label: "Suspicious protocols", icon: "&#128225;", match: a => /^POL-/.test(a.rule_id)},
  {label: "Exfiltration", icon: "&#128228;", match: a => /^EXF-/.test(a.rule_id)},
  {label: "Lateral movement", icon: "&#8644;", match: a => /^LAT-/.test(a.rule_id)},
];
