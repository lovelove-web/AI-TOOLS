/* Rendering helpers for packet / session drill-down. */
NIDS.view = {
  flags(str) {
    return str ? str.split("+").map(f => `<span class="flag">${NIDS.esc(f)}</span>`).join("") : '<span class="muted">-</span>';
  },

  kv(pairs) {
    return "<dl class='kv'>" + pairs.filter(p => p[1] !== undefined && p[1] !== "" && p[1] !== null)
      .map(([k, v]) => `<dt>${NIDS.esc(k)}</dt><dd>${v}</dd>`).join("") + "</dl>";
  },

  packet(d) {
    if (!d || !d.src) return '<div class="empty">No packet data stored for this alert</div>';
    const meta = Object.entries(d.metadata || {}).map(([k, v]) => [k, `<span class="mono">${NIDS.esc(v)}</span>`]);
    const app = d.app_protocol && d.app_protocol !== "UNKNOWN" ? " / " + NIDS.esc(d.app_protocol) : "";
    const icmp = d.icmp_type !== null && d.icmp_type !== undefined ? d.icmp_type : "";
    const rows = NIDS.view.kv([
      ["Time", NIDS.fmtDateTime(d.ts)],
      ["Source", `<span class="mono">${NIDS.esc(d.src)}:${d.sport || "-"}</span> ${NIDS.esc(d.src_mac)}`],
      ["Destination", `<span class="mono">${NIDS.esc(d.dst)}:${d.dport || "-"}</span> ${NIDS.esc(d.dst_mac)}`],
      ["Protocol", NIDS.esc(d.protocol) + app],
      ["TCP flags", d.protocol === "TCP" ? NIDS.view.flags(d.tcp_flags) : ""],
      ["Length", d.length + " bytes"], ["Fragmented", d.fragment ? "yes" : ""], ["ICMP type", icmp], ...meta]);
    const payload = d.payload_hex ? `<div class="muted">Payload (first bytes)</div>
      <div class="hex mono">${NIDS.esc(d.payload_ascii)}</div>
      <div class="hex mono" style="margin-top:6px">${NIDS.esc(d.payload_hex)}</div>` : "";
    return rows + payload;
  },

  related(list) {
    if (!list || !list.length) return '<div class="muted">No related packets were buffered.</div>';
    const rows = list.map(p => `<tr><td>${NIDS.fmtTime(p.ts)}</td><td class="mono">${NIDS.esc(p.src)}:${p.sport || ""}</td>
      <td class="mono">${NIDS.esc(p.dst)}:${p.dport || ""}</td>
      <td>${NIDS.esc(p.app_protocol !== "UNKNOWN" ? p.app_protocol : p.protocol)}</td>
      <td>${NIDS.esc(p.tcp_flags)}</td><td>${p.length}</td></tr>`).join("");
    return `<div class="table-wrap short"><table><thead><tr><th>Time</th><th>Src</th><th>Dst</th><th>Proto</th>
      <th>Flags</th><th>Len</th></tr></thead><tbody>${rows}</tbody></table></div>`;
  },
};
