/* Rule / signature / threshold management (admin can edit, others read-only). */
NIDS.rules = (function () {
  const SEVS = ["LOW", "MEDIUM", "HIGH", "CRITICAL"];
  const isAdmin = () => NIDS.role === "admin";
  const dis = () => (isAdmin() ? "" : "disabled");

  const toggle = (attr, id, on) => `<label class="switch"><input type="checkbox" ${attr}="${NIDS.esc(id)}" ${on ? "checked" : ""} ${dis()}><span></span></label>`;

  function rulesTable(rules) {
    const rows = rules.map(r => `<tr><td>${toggle("data-rule", r.rule_id, r.enabled)}</td>
      <td class="mono">${NIDS.esc(r.rule_id)}</td><td>${NIDS.esc(r.name)}</td><td>${NIDS.esc(r.category)}</td>
      <td><select data-sev="${NIDS.esc(r.rule_id)}" ${dis()}>${SEVS.map(s =>
        `<option ${s === r.severity ? "selected" : ""}>${s}</option>`).join("")}</select></td>
      <td class="mono muted" title="${NIDS.esc(r.pattern)}">${NIDS.esc(r.pattern.slice(0, 46))}${r.pattern.length > 46 ? "..." : ""}</td>
      <td>${r.custom && isAdmin() ? `<button class="btn small danger" data-del="${NIDS.esc(r.rule_id)}">Delete</button>` : ""}</td></tr>`).join("");
    return `<table><thead><tr><th>On</th><th>ID</th><th>Name</th><th>Category</th><th>Severity</th><th>Pattern</th><th></th></tr></thead><tbody>${rows}</tbody></table>`;
  }

  function detectorsTable(list) {
    return `<table><tbody>${list.map(d => `<tr><td>${toggle("data-det", d.name, d.enabled)}</td>
      <td><b>${NIDS.esc(d.name)}</b></td></tr>`).join("")}</tbody></table>
      <p class="muted">Disabling an engine stops all of its detections (e.g. turn off <code>baseline</code> on a very bursty lab network).</p>`;
  }

  function thresholdsTable(list) {
    return `<table><thead><tr><th>Setting</th><th>Value</th><th>Default</th><th></th></tr></thead><tbody>${list.map(t => {
      const changed = t.value !== t.default;
      return `<tr><td class="mono">${NIDS.esc(t.key)}</td>
        <td><input type="number" step="any" data-th="${NIDS.esc(t.key)}" value="${Number(t.value)}" ${dis()}></td>
        <td class="muted">${Number(t.default)}</td>
        <td>${changed && isAdmin() ? `<button class="btn small" data-reset="${NIDS.esc(t.key)}">Reset</button>` : ""}</td></tr>`;
    }).join("")}</tbody></table>`;
  }

  async function refresh() {
    const d = await NIDS.get("/api/rules");
    document.getElementById("rulesTable").innerHTML = rulesTable(d.rules);
    document.getElementById("detectorsTable").innerHTML = detectorsTable(d.detectors);
    document.getElementById("thresholdTable").innerHTML = thresholdsTable(d.thresholds);
    document.getElementById("addRuleBtn").classList.toggle("hidden", !isAdmin());
  }

  async function send(promise, message) {
    try { await promise; NIDS.toast(message); } catch (e) { NIDS.toast(e.message, true); }
    refresh();
  }

  function init() {
    const tab = document.getElementById("tab-rules");
    tab.addEventListener("change", e => {
      const t = e.target;
      if (t.dataset.rule) send(NIDS.post("/api/rules/" + t.dataset.rule, {enabled: t.checked}), `Rule ${t.dataset.rule} ${t.checked ? "enabled" : "disabled"}`);
      else if (t.dataset.det) send(NIDS.post("/api/detectors/" + t.dataset.det, {enabled: t.checked}), `Engine ${t.dataset.det} ${t.checked ? "enabled" : "disabled"}`);
      else if (t.dataset.sev) send(NIDS.post("/api/rules/" + t.dataset.sev, {severity: t.value}), `Severity of ${t.dataset.sev} set to ${t.value}`);
      else if (t.dataset.th) send(NIDS.post("/api/thresholds/" + t.dataset.th, {value: Number(t.value)}), `Threshold ${t.dataset.th} updated`);
    });
    tab.addEventListener("click", e => {
      const t = e.target;
      if (t.dataset.del && confirm("Delete rule " + t.dataset.del + "?")) send(NIDS.api("DELETE", "/api/rules/" + t.dataset.del), "Rule deleted");
      if (t.dataset.reset) send(NIDS.post("/api/thresholds/" + t.dataset.reset, {reset: true}), "Threshold reset to default");
    });
    const modal = document.getElementById("modal"), form = document.getElementById("ruleForm");
    document.getElementById("addRuleBtn").onclick = () => { form.reset(); modal.classList.remove("hidden"); };
    document.getElementById("ruleCancel").onclick = () => modal.classList.add("hidden");
    form.onsubmit = async e => {
      e.preventDefault();
      try {
        await NIDS.post("/api/rules", Object.fromEntries(new FormData(form)));
        modal.classList.add("hidden"); NIDS.toast("Custom rule added"); refresh();
      } catch (err) { document.getElementById("ruleError").textContent = err.message; }
    };
  }

  return {init, refresh};
})();
