/* Alerts tab: live feed, severity/status filters, bulk actions, export. */
NIDS.alerts = (function () {
  const S = {sev: new Set(NIDS.SEVERITIES), status: "", q: "", live: true, selected: new Set(), rows: [], lastId: 0};

  function renderFilters() {
    document.getElementById("sevFilters").innerHTML = NIDS.SEVERITIES.map(s =>
      `<button class="chip ${S.sev.has(s) ? "on" : ""}" data-sev="${s}">${s}</button>`).join("");
  }

  function query() {
    const p = new URLSearchParams({limit: 200});
    if (S.sev.size && S.sev.size < NIDS.SEVERITIES.length) p.set("severity", [...S.sev].join(","));
    if (S.status) p.set("status", S.status);
    if (S.q) p.set("q", S.q);
    return p.toString();
  }

  function table(rows, opts) {
    opts = opts || {};
    if (!rows.length) return '<div class="empty">No alerts match the current filters</div>';
    const head = `<tr>${opts.select ? '<th><input type="checkbox" id="selAll"></th>' : ""}<th>Time</th><th>Severity</th>
      <th>Attack type</th><th>Source</th><th>Destination</th><th>Port</th><th>Proto</th><th>Confidence</th>
      <th>Count</th><th>Status</th></tr>`;
    const body = rows.map(a => `<tr class="row ${a.severity} ${a.id > (opts.fresh || Infinity) ? "fresh" : ""}" data-id="${a.id}">
      ${opts.select ? `<td><input type="checkbox" class="sel" data-id="${a.id}" ${S.selected.has(a.id) ? "checked" : ""}></td>` : ""}
      <td title="${NIDS.esc(NIDS.fmtDateTime(a.ts))}">${NIDS.fmtTime(a.ts)}</td><td>${NIDS.sevBadge(a.severity)}</td>
      <td><b>${NIDS.esc(a.name)}</b><div class="muted mono">${NIDS.esc(a.rule_id)}</div></td>
      <td class="mono">${NIDS.esc(a.src)}${a.sport ? ":" + a.sport : ""}</td><td class="mono">${NIDS.esc(a.dst)}</td>
      <td class="mono">${a.dport || "-"}</td><td>${NIDS.esc(a.protocol)}</td><td>${NIDS.confBar(a.confidence)}</td>
      <td>${a.count > 1 ? "&times;" + a.count : "1"}</td><td>${NIDS.statusBadge(a.status)}</td></tr>`).join("");
    return `<table><thead>${head}</thead><tbody>${body}</tbody></table>`;
  }

  async function refresh(announce) {
    const data = await NIDS.get("/api/alerts?" + query());
    const previous = S.lastId;
    S.rows = data.alerts;
    S.lastId = Math.max(S.lastId, ...S.rows.map(r => r.id), 0);
    const box = document.getElementById("alertTable");
    box.innerHTML = table(S.rows, {select: NIDS.role !== "viewer", fresh: announce ? previous : Infinity});
    if (announce && previous) {
      const fresh = S.rows.filter(r => r.id > previous && (r.severity === "CRITICAL" || r.severity === "HIGH"));
      if (fresh.length) NIDS.toast(`${fresh.length} new ${fresh[0].severity} alert(s): ${fresh[0].name}`, true);
    }
  }

  function exportAlerts(fmt) {
    const p = new URLSearchParams(query()); p.set("format", fmt); p.set("limit", 500);
    NIDS.download("/api/export?" + p.toString(), "alerts." + fmt)
      .then(() => NIDS.toast("Export ready: " + fmt.toUpperCase()))
      .catch(e => NIDS.toast(e.message, true));
  }

  async function bulk(status) {
    if (!S.selected.size) return NIDS.toast("Select alerts first", true);
    try {
      const r = await NIDS.post("/api/alerts/bulk", {ids: [...S.selected], status});
      NIDS.toast(`${r.updated} alert(s) marked ${status}`);
      S.selected.clear(); refresh();
    } catch (e) { NIDS.toast(e.message, true); }
  }

  function init() {
    renderFilters();
    document.getElementById("sevFilters").addEventListener("click", e => {
      const s = e.target.dataset.sev; if (!s) return;
      S.sev.has(s) ? S.sev.delete(s) : S.sev.add(s); renderFilters(); refresh();
    });
    document.getElementById("statusFilter").onchange = e => { S.status = e.target.value; refresh(); };
    let timer;
    document.getElementById("searchBox").oninput = e => {
      clearTimeout(timer); timer = setTimeout(() => { S.q = e.target.value.trim(); refresh(); }, 300);
    };
    document.getElementById("liveToggle").onchange = e => { S.live = e.target.checked; };
    document.getElementById("alertTable").addEventListener("click", e => {
      if (e.target.id === "selAll") {
        S.rows.forEach(r => e.target.checked ? S.selected.add(r.id) : S.selected.delete(r.id));
        return refresh();
      }
      if (e.target.classList.contains("sel")) {
        const id = Number(e.target.dataset.id);
        e.target.checked ? S.selected.add(id) : S.selected.delete(id); return;
      }
      const tr = e.target.closest("tr.row"); if (tr) NIDS.drawer.open(Number(tr.dataset.id));
    });
    document.getElementById("bulkAck").onclick = () => bulk("acknowledged");
    document.getElementById("bulkResolve").onclick = () => bulk("resolved");
    document.querySelectorAll("[data-export]").forEach(a => a.onclick = () => exportAlerts(a.dataset.export));
  }

  return {init, refresh, table, state: S, tick: () => S.live && refresh(true),
          filterBy(sevs) { S.sev = new Set(sevs); renderFilters(); }, setText(q) {
            S.q = q; document.getElementById("searchBox").value = q; }};
})();
