/* Sensor and system health panel. */
NIDS.health = (function () {
  const HEARTBEAT_WARN_SECONDS = 15, DROP_WARN = 0.01, DROP_BAD = 0.05;

  const led = (cls) => `<span class="led ${cls}"></span>`;
  const row = (label, value, cls) => `<tr><td>${cls ? led(cls) : ""}${label}</td><td style="text-align:right"><b>${value}</b></td></tr>`;

  function panel(title, rows) {
    return `<div class="panel"><h3>${title}</h3><table><tbody>${rows.join("")}</tbody></table></div>`;
  }

  function render(h, ifaces) {
    const dropCls = h.drop_rate >= DROP_BAD ? "bad" : h.drop_rate >= DROP_WARN ? "warn" : "ok";
    const beatCls = h.heartbeat_age > HEARTBEAT_WARN_SECONDS ? "bad" : "ok";
    const active = new Set(h.interfaces);
    const names = ifaces.filter(i => active.has(i.id)).map(i => NIDS.esc(i.description || i.name));
    document.getElementById("healthPanel").innerHTML = `<div class="health-grid">` +
      panel("Sensor", [
        row("Capture", h.monitoring ? "Running" : "Stopped", h.monitoring ? "ok" : "bad"),
        row("Mode", h.mode === "ips" ? "IPS (blocking, approval required)" : "IDS (alert only)", "ok"),
        row("Uptime", NIDS.fmtDuration(h.uptime)),
        row("Last heartbeat", NIDS.fmtDuration(h.heartbeat_age) + " ago", beatCls),
        row("Last error", NIDS.esc(h.last_error) || "none", h.last_error ? "bad" : "ok")]) +
      panel("Network interfaces", names.length ? names.map(n => row(n, h.monitoring ? "capturing" : "idle",
        h.monitoring ? "ok" : "warn")) : [row("No interface selected", "default", "warn")]) +
      panel("Packet pipeline", [
        row("Packets captured", NIDS.fmtNum(h.packets_captured)),
        row("Packets analysed", NIDS.fmtNum(h.packets_analysed)),
        row("Packets dropped", NIDS.fmtNum(h.packets_dropped), dropCls),
        row("Drop rate", (h.drop_rate * 100).toFixed(2) + "%", dropCls),
        row("Queue depth", `${NIDS.fmtNum(h.queue_depth)} / ${NIDS.fmtNum(h.queue_capacity)}`)]) +
      panel("Detection engine", [
        row("Worker thread", h.worker_alive ? "alive" : "not running", h.worker_alive ? "ok" : "bad"),
        row("Detectors enabled", `${h.detectors_enabled} / ${h.detectors_total}`,
          h.detectors_enabled === h.detectors_total ? "ok" : "warn"),
        row("ML model", h.ml_loaded ? "loaded" : "not loaded", h.ml_loaded ? "ok" : "warn"),
        row("Threat-intel entries", NIDS.fmtNum(h.threat_intel_entries)),
        row("Alerts raised / suppressed", `${NIDS.fmtNum(h.alerts_total)} / ${NIDS.fmtNum(h.alerts_suppressed)}`)]) +
      `</div>`;
  }

  async function refresh() {
    const [h, i] = await Promise.all([NIDS.get("/api/health"), NIDS.get("/api/interfaces")]);
    render(h, i.interfaces);
    return h;
  }

  return {refresh};
})();
