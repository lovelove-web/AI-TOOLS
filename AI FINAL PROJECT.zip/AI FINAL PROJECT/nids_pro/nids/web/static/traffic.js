/* Traffic tab: pps, bandwidth, protocol mix, top talkers, targeted ports. */
NIDS.traffic = (function () {
  const BITS_PER_BYTE = 8, MEGA = 1e6;

  async function refresh() {
    const s = await NIDS.get("/api/stats");
    const pps = s.series.map(p => ({t: p.t, v: p.pps}));
    const bps = s.series.map(p => ({t: p.t, v: p.bps * BITS_PER_BYTE / MEGA}));
    NIDS.charts.line(document.getElementById("chartPps"), pps, "#6366f1", v => NIDS.fmtNum(Math.round(v)));
    NIDS.charts.line(document.getElementById("chartBps"), bps, "#22c55e", v => v.toFixed(2));
    NIDS.charts.doughnut(document.getElementById("chartProto"), s.protocols);
    document.getElementById("talkers").innerHTML =
      NIDS.barList(s.top_talkers, r => r.ip, r => r.bytes, NIDS.fmtBytes);
    document.getElementById("ports").innerHTML =
      NIDS.barList(s.top_ports, r => r.port + (NIDS.PORT_NAMES[r.port] ? " (" + NIDS.PORT_NAMES[r.port] + ")" : ""),
        r => r.count, NIDS.fmtNum);
  }

  return {refresh};
})();

NIDS.PORT_NAMES = {21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS", 80: "HTTP", 110: "POP3",
  135: "RPC", 139: "NetBIOS", 143: "IMAP", 443: "HTTPS", 445: "SMB", 1433: "MSSQL", 1883: "MQTT",
  3306: "MySQL", 3389: "RDP", 5432: "Postgres", 5900: "VNC", 8080: "HTTP-alt"};
