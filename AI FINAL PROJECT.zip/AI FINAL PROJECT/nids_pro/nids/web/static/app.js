/* App controller: login, tab navigation, polling, start/stop monitoring. */
(function () {
  const POLL_MS = 2000;
  const REFRESHERS = {
    overview: h => NIDS.overview.refresh(h), alerts: () => NIDS.alerts.tick(), traffic: () => NIDS.traffic.refresh(),
    rules: () => NIDS.rules.refresh(), health: () => NIDS.health.refresh(), admin: () => NIDS.admin.refresh(),
  };
  const SLOW_TABS = new Set(["rules", "admin"]);          // loaded on demand, not every poll
  let tab = "overview", health = {}, timer = null, ifaceLoaded = false;
  const $ = id => document.getElementById(id);

  NIDS.showTab = function (name) {
    tab = name;
    document.querySelectorAll("#tabs button").forEach(b => b.classList.toggle("active", b.dataset.tab === name));
    document.querySelectorAll(".tab").forEach(t => t.classList.toggle("active", t.id === "tab-" + name));
    if (name === "alerts") NIDS.alerts.refresh();
    poll(true);
  };

  NIDS.logout = function () {
    sessionStorage.removeItem("nids_token"); NIDS.token = ""; clearInterval(timer);
    $("app").classList.add("hidden"); $("login").classList.remove("hidden");
  };

  function paintStatus(h) {
    const pill = $("statusPill"), btn = $("monitorBtn");
    pill.textContent = h.monitoring ? "MONITORING" : "STOPPED";
    pill.className = "pill " + (h.monitoring ? "on" : "off");
    btn.innerHTML = h.monitoring ? "&#9632; Stop monitoring" : "&#9654; Start monitoring";
    btn.classList.toggle("running", !!h.monitoring);
    btn.disabled = NIDS.role === "viewer";
    $("ifaceSelect").disabled = h.monitoring || NIDS.role === "viewer";
  }

  async function loadInterfaces() {
    const d = await NIDS.get("/api/interfaces");
    $("ifaceSelect").innerHTML = '<option value="">Default interface</option>' + d.interfaces.map(i =>
      `<option value="${NIDS.esc(i.id)}" ${d.active.includes(i.id) ? "selected" : ""}>
       ${NIDS.esc(i.description || i.name)}${i.ip ? " (" + NIDS.esc(i.ip) + ")" : ""}</option>`).join("");
    ifaceLoaded = true;
  }

  async function poll(force) {
    try {
      health = await NIDS.get("/api/health");
      paintStatus(health);
      if (!SLOW_TABS.has(tab) || force) await REFRESHERS[tab](health);
    } catch (e) { if (NIDS.token) NIDS.toast("Connection problem: " + e.message, true); }
  }

  async function toggleMonitoring() {
    const btn = $("monitorBtn"); btn.disabled = true;
    try {
      if (health.monitoring) { await NIDS.post("/api/monitor/stop"); NIDS.toast("Monitoring stopped"); }
      else {
        const iface = $("ifaceSelect").value;
        await NIDS.post("/api/monitor/start", {interfaces: iface ? [iface] : []});
        NIDS.toast("Monitoring started");
      }
    } catch (e) { NIDS.toast(e.message, true); }
    await poll(true);
  }

  async function start() {
    const me = await NIDS.get("/api/me");
    NIDS.role = me.role;
    $("roleBadge").textContent = me.role;
    $("login").classList.add("hidden"); $("app").classList.remove("hidden");
    document.querySelectorAll(".admin-only").forEach(e => e.classList.toggle("hidden", me.role !== "admin"));
    if (!ifaceLoaded) await loadInterfaces();
    await poll(true);
    clearInterval(timer); timer = setInterval(poll, POLL_MS);
  }

  document.addEventListener("DOMContentLoaded", () => {
    NIDS.alerts.init(); NIDS.drawer.init(); NIDS.rules.init(); NIDS.admin.init();
    $("tabs").addEventListener("click", e => { if (e.target.dataset.tab) NIDS.showTab(e.target.dataset.tab); });
    $("monitorBtn").onclick = toggleMonitoring;
    $("logout").onclick = NIDS.logout;
    $("loginForm").addEventListener("submit", async e => {
      e.preventDefault();
      NIDS.token = $("tokenInput").value.trim();
      try { await start(); sessionStorage.setItem("nids_token", NIDS.token); $("loginError").textContent = ""; }
      catch (err) { NIDS.token = ""; $("loginError").textContent = "Invalid token"; }
    });
    window.addEventListener("resize", () => poll(true));
    if (NIDS.token) start().catch(NIDS.logout); else $("login").classList.remove("hidden");
  });
})();
