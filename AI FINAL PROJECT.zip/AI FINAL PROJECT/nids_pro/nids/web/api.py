"""REST API logic. Each handler returns (status, payload) or a Raw for binary downloads."""
from __future__ import annotations

import time
from dataclasses import dataclass

from .. import reports, workflow
from ..capture import list_interfaces
from ..constants import MAX_ALERT_PAGE


@dataclass
class Raw:
    body: bytes
    content_type: str
    filename: str = ""


class ApiError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status, self.message = status, message


def _int(params: dict, key: str, default: int = 0) -> int:
    try:
        return int(params.get(key, default))
    except (TypeError, ValueError):
        raise ApiError(400, f"'{key}' must be an integer")


def _filters(params: dict) -> dict:
    return {"severity": params.get("severity", ""), "status": params.get("status", ""),
            "text": params.get("q", "")[:100], "category": params.get("category", ""),
            "since": float(params.get("since", 0) or 0)}


class Api:
    def __init__(self, engine):
        self.e = engine

    # ------------------------------------------------------------------ read
    def health(self, ctx, params, body):
        return 200, self.e.health()

    def interfaces(self, ctx, params, body):
        return 200, {"interfaces": list_interfaces(), "active": self.e.active_interfaces,
                     "monitoring": self.e.monitoring}

    def stats(self, ctx, params, body):
        data = self.e.stats.snapshot()
        data["monitoring"] = self.e.monitoring
        return 200, data

    def summary(self, ctx, params, body):
        data = workflow.summary(self.e.db, float(params.get("since", 0) or 0))
        # per-rule totals (not truncated) feed the attack-type widgets
        data["top_rules_all"] = self.e.db.query(
            "SELECT rule_id, severity, COUNT(*) n FROM alerts GROUP BY rule_id, severity")
        return 200, data

    def alerts(self, ctx, params, body):
        rows = workflow.query_alerts(
            self.e.db, limit=_int(params, "limit", 100), offset=_int(params, "offset", 0), **_filters(params))
        after = _int(params, "after_id", 0)
        if after:
            rows = [r for r in rows if r["id"] > after]
        return 200, {"alerts": rows}

    def alert_detail(self, ctx, params, body, alert_id):
        alert = workflow.get_alert(self.e.db, int(alert_id))
        if alert is None:
            raise ApiError(404, "alert not found")
        same = self.e.db.query("SELECT id, ts, name, severity, dport, status FROM alerts WHERE src=? AND id<>? "
                               "ORDER BY id DESC LIMIT 15", (alert["src"], alert["id"]))
        return 200, {"alert": alert, "related_alerts": same}

    def assets(self, ctx, params, body):
        return 200, {"assets": self.e.db.query("SELECT * FROM assets ORDER BY last_seen DESC LIMIT 200")}

    def actions(self, ctx, params, body):
        return 200, {"actions": self.e.db.query("SELECT * FROM actions ORDER BY id DESC LIMIT 100")}

    def audit(self, ctx, params, body):
        return 200, {"audit": self.e.db.query("SELECT * FROM audit ORDER BY id DESC LIMIT 200")}

    def rules(self, ctx, params, body):
        return 200, {"rules": self.e.rules.list_rules(), "detectors": self.e.rules.list_detectors(),
                     "thresholds": self.e.rules.list_thresholds()}

    def me(self, ctx, params, body):
        return 200, {"role": ctx["role"], "user": ctx["user"], "mode": self.e.cfg.mode}

    # ---------------------------------------------------------------- export
    def export(self, ctx, params, body):
        fmt = params.get("format", "csv")
        limit = min(_int(params, "limit", MAX_ALERT_PAGE), MAX_ALERT_PAGE)
        alerts = workflow.query_alerts(self.e.db, limit=limit, full=True, **_filters(params))
        stamp = time.strftime("%Y%m%d-%H%M%S")
        self.e.db.audit(ctx["user"], "export", f"format={fmt} rows={len(alerts)}")
        if fmt == "json":
            return Raw(reports.to_json(alerts), "application/json", f"nids-alerts-{stamp}.json")
        if fmt == "pdf":
            summary = workflow.summary(self.e.db, _filters(params)["since"])
            return Raw(reports.to_pdf(alerts, summary), "application/pdf", f"nids-report-{stamp}.pdf")
        if fmt == "csv":
            return Raw(reports.to_csv(alerts), "text/csv; charset=utf-8", f"nids-alerts-{stamp}.csv")
        raise ApiError(400, "format must be csv, json or pdf")
