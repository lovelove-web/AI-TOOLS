"""Route table: (method, path regex, minimum role, handler)."""
from __future__ import annotations

import re

ROLE_LEVEL = {"viewer": 1, "analyst": 2, "admin": 3}


def build_routes(api):
    table = [
        ("GET", r"/api/me", "viewer", api.me),
        ("GET", r"/api/health", "viewer", api.health),
        ("GET", r"/api/interfaces", "viewer", api.interfaces),
        ("GET", r"/api/stats", "viewer", api.stats),
        ("GET", r"/api/summary", "viewer", api.summary),
        ("GET", r"/api/alerts", "viewer", api.alerts),
        ("GET", r"/api/alerts/(\d+)", "viewer", api.alert_detail),
        ("GET", r"/api/assets", "viewer", api.assets),
        ("GET", r"/api/actions", "viewer", api.actions),
        ("GET", r"/api/rules", "viewer", api.rules),
        ("GET", r"/api/export", "viewer", api.export),
        ("GET", r"/api/audit", "admin", api.audit),
        ("POST", r"/api/monitor/start", "analyst", api.monitor_start),
        ("POST", r"/api/monitor/stop", "analyst", api.monitor_stop),
        ("POST", r"/api/alerts/bulk", "analyst", api.alerts_bulk),
        ("POST", r"/api/alerts/(\d+)", "analyst", api.alert_update),
        ("POST", r"/api/actions/(\d+)/(approve|reject)", "admin", api.action_decide),
        ("POST", r"/api/rules", "admin", api.rule_add),
        ("POST", r"/api/rules/([A-Za-z0-9_-]+)", "admin", api.rule_update),
        ("DELETE", r"/api/rules/([A-Za-z0-9_-]+)", "admin", api.rule_delete),
        ("POST", r"/api/detectors/([a-z_0-9]+)", "admin", api.detector_update),
        ("POST", r"/api/thresholds/([a-z_0-9]+)", "admin", api.threshold_update),
    ]
    return [(m, re.compile(p + r"$"), role, fn) for m, p, role, fn in table]
