"""Threaded HTTP handler: token auth, role enforcement, static files, security headers."""
from __future__ import annotations

import hmac
import json
from http.server import BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from ..constants import MAX_REQUEST_BYTES
from .actions import ActionApi
from .api import ApiError, Raw
from .routes import ROLE_LEVEL, build_routes

STATIC_DIR = Path(__file__).parent / "static"
CONTENT_TYPES = {".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
                 ".js": "application/javascript; charset=utf-8", ".svg": "image/svg+xml"}
SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer",
    "Cache-Control": "no-store",
    "Content-Security-Policy": "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:",
}


def make_handler(api: ActionApi, tokens: dict[str, str], allowed_hosts: set[str]):
    routes = build_routes(api)

    class Handler(BaseHTTPRequestHandler):
        server_version = "NIDS"

        def log_message(self, *args):          # keep the console free for alerts
            pass

        def _send(self, status: int, body: bytes, ctype: str, extra: dict | None = None):
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            for key, value in {**SECURITY_HEADERS, **(extra or {})}.items():
                self.send_header(key, value)
            self.end_headers()
            self.wfile.write(body)

        def _json(self, status: int, payload):
            self._send(status, json.dumps(payload, default=str).encode(), "application/json")

        def _identify(self):
            header = self.headers.get("Authorization", "")
            supplied = header[7:].strip() if header.startswith("Bearer ") else ""
            found = None
            for token, role in tokens.items():          # constant-time compare, no early exit
                if supplied and hmac.compare_digest(token, supplied):
                    found = {"role": role, "user": f"{role}:{token[:4]}"}
            return found

        def _host_ok(self) -> bool:
            """Reject unexpected Host headers (DNS-rebinding protection)."""
            host = self.headers.get("Host", "").rsplit(":", 1)[0].strip("[]")
            return host in allowed_hosts

        def _read_body(self) -> dict:
            length = int(self.headers.get("Content-Length") or 0)
            if length > MAX_REQUEST_BYTES:
                raise ApiError(413, "request too large")
            if not length:
                return {}
            try:
                data = json.loads(self.rfile.read(length))
            except ValueError:
                raise ApiError(400, "body must be valid JSON")
            if not isinstance(data, dict):
                raise ApiError(400, "body must be a JSON object")
            return data

        def do_GET(self):
            self._dispatch("GET")

        def do_POST(self):
            self._dispatch("POST")

        def do_DELETE(self):
            self._dispatch("DELETE")

        def _dispatch(self, method: str):
            if not self._host_ok():
                return self._json(403, {"error": "host not allowed"})
            url = urlparse(self.path)
            if method == "GET" and not url.path.startswith("/api/"):
                return self._static(url.path)
            params = {k: v[0] for k, v in parse_qs(url.query).items()}
            for verb, pattern, role, handler in routes:
                match = pattern.match(url.path)
                if verb != method or not match:
                    continue
                ctx = self._identify()
                if ctx is None:
                    return self._json(401, {"error": "authentication required"})
                if ROLE_LEVEL[ctx["role"]] < ROLE_LEVEL[role]:
                    return self._json(403, {"error": f"{role} role required"})
                return self._run(handler, ctx, params, match.groups(), method, url.path)
            self._json(404, {"error": "not found"})

        def _run(self, handler, ctx, params, args, method, path):
            try:
                body = self._read_body() if method in ("POST", "DELETE") else {}
                result = handler(ctx, params, body, *args)
            except ApiError as err:
                return self._json(err.status, {"error": err.message})
            except Exception as exc:        # never leak a traceback to the client
                print(f"[!] API error on {method} {path}: {exc!r}")
                return self._json(500, {"error": "internal error"})
            if isinstance(result, Raw):
                disposition = {"Content-Disposition": f'attachment; filename="{result.filename}"'}
                return self._send(200, result.body, result.content_type, disposition)
            self._json(*result)

        def _static(self, path: str):
            name = "index.html" if path in ("", "/") else path.lstrip("/")
            target = (STATIC_DIR / name).resolve()
            if STATIC_DIR.resolve() not in target.parents or not target.is_file():
                return self._json(404, {"error": "not found"})
            self._send(200, target.read_bytes(), CONTENT_TYPES.get(target.suffix, "application/octet-stream"))

    return Handler
