"""State-changing API handlers (analyst / admin only; role checks are enforced by the router)."""
from __future__ import annotations

import re

from .. import workflow
from ..constants import ALERT_STATUSES, Severity
from .api import Api, ApiError


class ActionApi(Api):
    def monitor_start(self, ctx, params, body):
        ifaces = body.get("interfaces") or self.e.cfg.interfaces
        if not isinstance(ifaces, list) or not all(isinstance(i, str) for i in ifaces):
            raise ApiError(400, "interfaces must be a list of interface ids")
        try:
            self.e.start_monitoring(ifaces)
        except (RuntimeError, ValueError, OSError) as exc:
            raise ApiError(409, str(exc))
        self.e.db.audit(ctx["user"], "monitor_start", ",".join(ifaces) or "default")
        return 200, {"monitoring": True}

    def monitor_stop(self, ctx, params, body):
        self.e.stop_monitoring()
        self.e.db.audit(ctx["user"], "monitor_stop", "")
        return 200, {"monitoring": False}

    def alert_update(self, ctx, params, body, alert_id):
        status = body.get("status")
        if status is not None and status not in ALERT_STATUSES:
            raise ApiError(400, f"status must be one of {list(ALERT_STATUSES)}")
        try:
            alert = workflow.update_alert(self.e.db, int(alert_id), status, body.get("note"), ctx["user"])
        except KeyError:
            raise ApiError(404, "alert not found")
        return 200, {"alert": alert}

    def alerts_bulk(self, ctx, params, body):
        ids, status = body.get("ids"), body.get("status")
        if not isinstance(ids, list) or not ids or len(ids) > 200 or status not in ALERT_STATUSES:
            raise ApiError(400, "provide up to 200 ids and a valid status")
        done = 0
        for i in ids:
            try:
                workflow.update_alert(self.e.db, int(i), status, body.get("note"), ctx["user"])
                done += 1
            except (KeyError, ValueError, TypeError):
                continue
        return 200, {"updated": done}

    def rule_update(self, ctx, params, body, rule_id):
        sev = body.get("severity")
        if sev is not None and sev not in Severity.__members__:
            raise ApiError(400, "invalid severity")
        self.e.rules.set_rule(rule_id, body.get("enabled"), sev)
        self.e.db.audit(ctx["user"], "rule_update", f"{rule_id} {body}")
        return 200, {"ok": True}

    def rule_add(self, ctx, params, body):
        try:
            self.e.rules.add_custom(str(body.get("rule_id", "")), str(body.get("name", "Custom rule")),
                                    str(body.get("pattern", "")), str(body.get("severity", "MEDIUM")),
                                    str(body.get("target", "payload")))
        except (ValueError, KeyError, re.error) as exc:
            raise ApiError(400, f"invalid rule: {exc}")
        self.e.db.audit(ctx["user"], "rule_add", str(body.get("rule_id")))
        return 200, {"ok": True}

    def rule_delete(self, ctx, params, body, rule_id):
        try:
            self.e.rules.delete_custom(rule_id)
        except ValueError as exc:
            raise ApiError(400, str(exc))
        self.e.db.audit(ctx["user"], "rule_delete", rule_id)
        return 200, {"ok": True}

    def detector_update(self, ctx, params, body, name):
        try:
            self.e.rules.set_detector(name, bool(body.get("enabled")))
        except KeyError:
            raise ApiError(404, "unknown detector")
        self.e.db.audit(ctx["user"], "detector_update", f"{name} enabled={body.get('enabled')}")
        return 200, {"ok": True}

    def threshold_update(self, ctx, params, body, key):
        try:
            if body.get("reset"):
                self.e.rules.reset_threshold(key)
            else:
                self.e.rules.set_threshold(key, float(body.get("value")))
        except KeyError:
            raise ApiError(404, "unknown threshold")
        except (TypeError, ValueError) as exc:
            raise ApiError(400, f"invalid value: {exc}")
        self.e.db.audit(ctx["user"], "threshold_update", f"{key}={body}")
        return 200, {"ok": True}

    def action_decide(self, ctx, params, body, action_id, verdict):
        result = self.e.response.decide(int(action_id), verdict == "approve", ctx["user"])
        return 200, {"result": result}
