"""Web dashboard and REST API."""
from .launcher import start_dashboard

__all__ = ["start_dashboard"]
