"""Start the dashboard HTTP server in a background thread."""
from __future__ import annotations

import secrets
import threading
from http.server import ThreadingHTTPServer

from .actions import ActionApi
from .routes import ROLE_LEVEL
from .server import make_handler


def start_dashboard(engine, cfg) -> ThreadingHTTPServer | None:
    d = cfg.dashboard
    if not d.get("enabled"):
        return None
    tokens = dict(d.get("tokens") or {})
    for role in tokens.values():
        if role not in ROLE_LEVEL:
            raise ValueError(f"invalid dashboard role {role!r}; use viewer, analyst or admin")
    generated = None
    if not tokens:
        generated = secrets.token_urlsafe(18)
        tokens[generated] = "admin"
    host, port = d["host"], d["port"]
    allowed = {"localhost", "127.0.0.1", "::1", host, *d.get("allowed_hosts", [])}
    server = ThreadingHTTPServer((host, port), make_handler(ActionApi(engine), tokens, allowed))
    threading.Thread(target=server.serve_forever, name="nids-dashboard", daemon=True).start()
    print(f"[+] Dashboard: http://{host}:{port}/")
    if generated:
        print(f"[+] No tokens configured - temporary admin token (this run only): {generated}")
    else:
        print("[+] Sign in with one of the tokens from your config file")
    return server
