"""Reconnaissance: ARP / ICMP / UDP discovery and scans (TCP scans live in scan_tcp.py)."""
from __future__ import annotations

from collections import defaultdict

from ..constants import (ICMP_ADDRMASK_REQUEST, ICMP_ECHO_REQUEST,
                         ICMP_TIMESTAMP_REQUEST, Severity)
from .base import Detector, Window


class ScanDetector(Detector):
    name = "scan"

    def __init__(self, cfg):
        super().__init__(cfg)
        w = self.t["scan_window"]
        self.udp = defaultdict(lambda: Window(w))
        self.pings = defaultdict(lambda: Window(w))
        self.arp = defaultdict(lambda: Window(w))

    def process(self, p):
        if p.is_arp:
            return self._arp(p)
        if p.is_icmp:
            return self._icmp(p)
        if p.is_udp:
            return self._udp(p)
        return []

    def _arp(self, p):
        if p.flags != 1:
            return []
        w = self.arp[p.src_mac or p.src]
        w.add(p.ts, p.dst)
        n = w.distinct()
        if n >= self.t["arp_sweep_hosts"] and self.once(("arp", p.src), p.ts):
            return [self.alert(p, "SCN-007", "ARP host discovery sweep", "recon", Severity.MEDIUM,
                               f"{p.src} ARPed {n} different hosts (nmap -sn / netdiscover)",
                               "T1018", dst="LAN")]
        return []

    def _icmp(self, p):
        out = []
        if p.icmp_type == ICMP_ECHO_REQUEST:
            w = self.pings[p.src]
            w.add(p.ts, p.dst)
            n = w.distinct()
            if n >= self.t["ping_sweep_hosts"]:
                if self.once(("sweep", p.src), p.ts):
                    out.append(self.alert(p, "SCN-006", "ICMP ping sweep (host discovery)", "recon",
                                          Severity.MEDIUM, f"{p.src} pinged {n} hosts in "
                                          f"{self.t['scan_window']}s", "T1018", hosts=n))
            elif self.t["alert_on_single_ping"] and self.once(("ping", p.src, p.dst), p.ts, 30):
                out.append(self.alert(p, "SCN-005", "ICMP echo request (ping)", "recon", Severity.LOW,
                                      f"{p.src} pinged {p.dst} - basic host discovery "
                                      "(ping / nmap -sn / -PE)", "T1595", size=p.length))
        elif p.icmp_type in (ICMP_TIMESTAMP_REQUEST, ICMP_ADDRMASK_REQUEST) \
                and self.once(("icmpx", p.src, p.dst), p.ts):
            out.append(self.alert(p, "SCN-008", "ICMP timestamp/netmask probe", "recon", Severity.MEDIUM,
                                  "nmap -PP/-PM discovery or OS fingerprinting", "T1595",
                                  icmp_type=p.icmp_type))
        return out

    def _udp(self, p):
        w = self.udp[(p.src, p.dst)]
        w.add(p.ts, p.dport)
        n = w.distinct()
        if n >= self.t["udp_scan_ports"] and len(p.payload) < 8 and self.once(("udp", p.src, p.dst), p.ts):
            return [self.alert(p, "SCN-004", "UDP port scan", "recon", Severity.MEDIUM,
                               f"{p.src} probed {n} UDP ports on {p.dst} (nmap -sU)", "T1046", ports=n)]
        return []
