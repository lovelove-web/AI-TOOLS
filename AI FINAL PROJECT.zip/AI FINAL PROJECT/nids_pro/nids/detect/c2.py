"""Malware / C2: DNS tunnelling, DGA, beaconing, threat-intel hits, bad JA3."""
from __future__ import annotations

import statistics
from collections import defaultdict

from ..constants import SYN, Severity
from ..packets import is_private, shannon_entropy
from .base import Detector, Window

DNS_TYPE_TXT = 16


class DnsDetector(Detector):
    name = "dns"

    def __init__(self, cfg, intel=None):
        super().__init__(cfg)
        self.intel = intel
        self.names = defaultdict(lambda: Window(self.t["dns_volume_window"]))
        self.txt = defaultdict(lambda: Window(self.t["dns_volume_window"]))

    def process(self, p):
        q = p.meta.get("dns_qname")
        if not q or p.meta.get("dns_response"):
            return []
        out, t = [], self.t
        labels = q.split(".")
        longest = max(labels, key=len)
        ent = shannon_entropy(longest)
        domain = ".".join(labels[-2:])
        if ((len(longest) >= t["dns_label_len"] and ent >= t["dns_label_entropy"])
                or len(q) >= t["dns_qname_len"] * 2) and self.once(("tun", p.src, domain), p.ts, 120):
            out.append(self.alert(p, "C2-001", "Possible DNS tunnelling / DGA", "c2", Severity.HIGH,
                                  f"{p.src} queried high-entropy name '{q[:70]}' (entropy {ent:.2f}) - "
                                  "iodine/dnscat2 tunnel or DGA malware", "T1071.004",
                                  entropy=round(ent, 2), qname=q))
        w = self.names[(p.src, domain)]
        w.add(p.ts, q)
        uniq = w.distinct()
        if uniq >= t["dns_unique_names"] and self.once(("vol", p.src, domain), p.ts, 120):
            out.append(self.alert(p, "EXF-002", "Abnormal DNS volume to one domain", "exfiltration",
                                  Severity.HIGH, f"{p.src} sent {uniq} unique subdomain queries to "
                                  f"{domain} in {t['dns_volume_window']}s - DNS exfiltration/tunnel",
                                  "T1048.003", domain=domain, unique=uniq))
        if p.meta.get("dns_qtype") == DNS_TYPE_TXT:
            tw = self.txt[p.src]
            tw.add(p.ts)
            if len(tw) >= t["dns_txt_count"] and self.once(("txt", p.src), p.ts, 120):
                out.append(self.alert(p, "C2-002", "Excessive DNS TXT queries", "c2", Severity.MEDIUM,
                                      f"{len(tw)} TXT lookups from {p.src}; common C2/tunnel channel",
                                      "T1071.004", count=len(tw)))
        if self.intel and self.intel.is_bad_domain(q) and self.once(("ti", p.src, q), p.ts, 120):
            out.append(self.alert(p, "TI-002", "Query for known-malicious domain", "c2",
                                  Severity.CRITICAL, f"{p.src} resolved {q} (threat-intel match)",
                                  "T1071.004", qname=q))
        return out


class BeaconDetector(Detector):
    """Periodic outbound connections with very low jitter."""
    name = "beacon"

    def __init__(self, cfg):
        super().__init__(cfg)
        self.times = defaultdict(list)

    def process(self, p):
        if not p.is_tcp or p.flags & 0x3F != SYN or not is_private(p.src) or is_private(p.dst):
            return []
        key, t = (p.src, p.dst, p.dport), self.t
        ts = self.times[key]
        ts.append(p.ts)
        del ts[:-40]
        if len(ts) < t["beacon_min_events"]:
            return []
        gaps = [b - a for a, b in zip(ts, ts[1:])]
        mean = statistics.fmean(gaps)
        if mean < t["beacon_min_interval"]:
            return []
        cv = statistics.pstdev(gaps) / mean
        if cv <= t["beacon_max_cv"] and self.once(key, p.ts, 600):
            return [self.alert(p, "C2-003", "C2 beaconing detected", "c2", Severity.HIGH,
                               f"{p.src} contacts {p.dst}:{p.dport} every {mean:.1f}s "
                               f"(jitter {cv * 100:.1f}%) - automated check-in", "T1071",
                               interval=round(mean, 2), jitter=round(cv, 3))]
        return []


class TlsDetector(Detector):
    """Suspicious TLS: blocklisted SNI / JA3-style fingerprint markers."""
    name = "tls"

    def __init__(self, cfg, intel=None):
        super().__init__(cfg)
        self.intel = intel

    def process(self, p):
        sni = p.meta.get("tls_sni")
        if sni and self.intel and self.intel.is_bad_domain(sni) and self.once(("sni", p.src, sni), p.ts, 120):
            return [self.alert(p, "TI-003", "TLS connection to malicious domain", "c2", Severity.CRITICAL,
                               f"{p.src} opened TLS session to {sni} (threat-intel match)", "T1071.001",
                               sni=sni)]
        ja3 = p.meta.get("ja3")
        if ja3 and ja3 in set(self.cfg.bad_ja3) and self.once(("ja3", p.src, ja3), p.ts, 300):
            return [self.alert(p, "C2-004", "Malicious TLS fingerprint (JA3)", "c2", Severity.HIGH,
                               f"{p.src} client fingerprint {ja3} matches known malware", "T1071.001",
                               ja3=ja3)]
        return []
