"""Brute force, password spraying and web-login attacks."""
from __future__ import annotations

from collections import defaultdict

from ..constants import AUTH_PORTS, SYN, Severity
from .base import Detector, Window

LOGIN_URI_HINTS = ("login", "signin", "auth", "wp-login", "admin")


class BruteForceDetector(Detector):
    name = "bruteforce"

    def __init__(self, cfg):
        super().__init__(cfg)
        w = self.t["bruteforce_window"]
        self.attempts = defaultdict(lambda: Window(w))
        self.targets = defaultdict(lambda: Window(w))
        self.logins = defaultdict(lambda: Window(w))

    def process(self, p):
        if not p.is_tcp:
            return []
        out, t = [], self.t
        svc = AUTH_PORTS.get(p.dport)
        if svc and p.flags & 0x3F == SYN:
            key = (p.src, p.dst, p.dport)
            w = self.attempts[key]
            w.add(p.ts)
            self.targets[(p.src, p.dport)].add(p.ts, p.dst)
            if len(w) >= t["bruteforce_attempts"] and self.once(key, p.ts):
                out.append(self.alert(p, "BRT-001", f"{svc} brute-force attack", "bruteforce",
                                      Severity.HIGH, f"{len(w)} new {svc} connections from {p.src} to "
                                      f"{p.dst}:{p.dport} in {t['bruteforce_window']}s "
                                      "(hydra/medusa/ncrack style)", "T1110", attempts=len(w), service=svc))
            hosts = self.targets[(p.src, p.dport)].distinct()
            if hosts >= t["scan_hosts"] and self.once(("spray", p.src, p.dport), p.ts, 120):
                out.append(self.alert(p, "BRT-002", f"{svc} password spraying", "bruteforce",
                                      Severity.HIGH, f"{p.src} tried {svc} on {hosts} different hosts",
                                      "T1110.003", dst="multiple", hosts=hosts))
        uri = p.meta.get("http_uri", "").lower()
        if p.meta.get("http_method") == "POST" and any(h in uri for h in LOGIN_URI_HINTS):
            w = self.logins[(p.src, p.dst)]
            w.add(p.ts)
            if len(w) >= t["web_login_attempts"] and self.once(("web", p.src, p.dst), p.ts):
                out.append(self.alert(p, "BRT-003", "Web login brute force", "bruteforce", Severity.HIGH,
                                      f"{len(w)} login POSTs from {p.src} to {p.dst}{uri[:40]}",
                                      "T1110", attempts=len(w)))
        return out
