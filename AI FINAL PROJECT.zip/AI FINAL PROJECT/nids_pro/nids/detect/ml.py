"""Machine-learning flow classifier (the original model, now one detector among many)."""
from __future__ import annotations

import json
import pickle
import warnings
from datetime import datetime

import numpy as np
import pandas as pd

from ..constants import (BENIGN_LABELS, FEATURE_NAMES, FLOW_HISTORY_LIMIT, ML_CHECKPOINT_EVERY,
                         ML_CHECKPOINTS, Severity)
from ..packets import ip_to_number, shannon_entropy
from .base import Detector


def import_pickle(db, pkl_path: str) -> None:
    """One-time import of a legacy .pkl bundle into SQLite.

    SECURITY: pickle can execute code on load - only import files you trained yourself.
    """
    with open(pkl_path, "rb") as fh:
        bundle = pickle.load(fh)          # noqa: S301 (trusted, user-supplied file)
    if list(bundle.get("feature_names", [])) != FEATURE_NAMES:
        raise ValueError("Pickle feature schema does not match FEATURE_NAMES")
    db.execute("UPDATE models SET is_active = 0")
    db.execute(
        "INSERT INTO models (model_name, accuracy, feature_names, model_blob, scaler_blob, created_at,"
        " is_active) VALUES (?,?,?,?,?,?,1)",
        (bundle.get("model_name", type(bundle["model"]).__name__), bundle.get("accuracy"),
         json.dumps(FEATURE_NAMES), pickle.dumps(bundle["model"]), pickle.dumps(bundle["scaler"]),
         datetime.now().isoformat()))


class Flow:
    __slots__ = ("src", "sport", "dst", "dport", "proto", "start", "last", "bytes_in", "bytes_out",
                 "pkts_in", "pkts_out", "times", "sizes")

    def __init__(self, p):
        self.src, self.sport, self.dst, self.dport, self.proto = p.src, p.sport, p.dst, p.dport, p.proto
        self.start = self.last = p.ts
        self.bytes_in = self.bytes_out = self.pkts_in = self.pkts_out = 0
        self.times: list[float] = []
        self.sizes: list[int] = []

    @property
    def packets(self) -> int:
        return self.pkts_in + self.pkts_out

    def update(self, p) -> None:
        self.last = p.ts
        self.times.append(p.ts)
        self.sizes.append(max(1, p.length))
        if p.src == self.src:
            self.bytes_out += p.length
            self.pkts_out += 1
        else:
            self.bytes_in += p.length
            self.pkts_in += 1
        del self.times[:-FLOW_HISTORY_LIMIT], self.sizes[:-FLOW_HISTORY_LIMIT]

    def features(self) -> list[float]:
        gaps = [b - a for a, b in zip(self.times, self.times[1:])]
        ent = shannon_entropy(self.sizes)
        v = {"avg_ipt": sum(gaps) / len(gaps) if gaps else 0.0, "bytes_in": self.bytes_in,
             "bytes_out": self.bytes_out, "dest_ip": ip_to_number(self.dst), "dest_port": self.dport,
             "duration": max(0.0, self.last - self.start), "entropy": ent, "num_pkts_in": self.pkts_in,
             "num_pkts_out": self.pkts_out, "proto": self.proto, "src_ip": ip_to_number(self.src),
             "src_port": self.sport, "time_end": self.last, "time_start": self.start, "total_entropy": ent}
        return [float(v[n]) for n in FEATURE_NAMES]


class MLDetector(Detector):
    name = "ml"

    def __init__(self, cfg, db):
        super().__init__(cfg)
        self.flows: dict[tuple, Flow] = {}
        self.available = False
        row = db.query("SELECT model_name, accuracy, model_blob, scaler_blob, feature_names FROM models "
                       "WHERE is_active = 1 ORDER BY id DESC LIMIT 1")
        if not row:
            print("[!] No ML model in database - ML detector disabled "
                  "(use: nids import-model <file.pkl>)")
            return
        if json.loads(row[0]["feature_names"]) != FEATURE_NAMES:
            raise ValueError("Stored model feature schema mismatch")
        warnings.filterwarnings("ignore", category=UserWarning, module="sklearn.base")
        self.model = pickle.loads(row[0]["model_blob"])     # noqa: S301 (own DB)
        self.scaler = pickle.loads(row[0]["scaler_blob"])   # noqa: S301
        self.model_name, self.accuracy, self.available = row[0]["model_name"], row[0]["accuracy"], True
        print(f"[+] ML model loaded: {self.model_name} (accuracy {self.accuracy})")

    def process(self, p):
        if not self.available or p.is_arp or not (p.is_tcp or p.is_udp or p.is_icmp):
            return []
        key = (p.src, p.sport, p.dst, p.dport, p.proto)
        rkey = (p.dst, p.dport, p.src, p.sport, p.proto)
        flow = self.flows.get(key) or self.flows.get(rkey)
        if flow is None:
            flow = self.flows[key] = Flow(p)
        flow.update(p)
        n = flow.packets
        if n not in ML_CHECKPOINTS and n % ML_CHECKPOINT_EVERY:
            return []
        scaled = self.scaler.transform(pd.DataFrame([flow.features()], columns=FEATURE_NAMES))
        label = str(self.model.predict(scaled)[0])
        if label.strip().lower() in BENIGN_LABELS:
            return []
        conf = None
        if hasattr(self.model, "predict_proba"):
            conf = float(np.max(self.model.predict_proba(scaled)[0]))
        if conf is not None and conf < self.t["ml_confidence"]:
            return []
        human = self.cfg.ml_labels.get(label, f"class '{label}'")
        return [self.alert(p, "ML-001", f"ML classifier: {human}", "anomaly", Severity.MEDIUM,
                           f"Flow {flow.src}:{flow.sport} -> {flow.dst}:{flow.dport} classified as "
                           f"{human} by {self.model_name}" + (f" (confidence {conf:.0%})" if conf else ""),
                           "", label=label, confidence=conf, packets=n)]

    def housekeeping(self, now):
        super().housekeeping(now)
        from ..constants import FLOW_IDLE_TIMEOUT
        self.flows = {k: f for k, f in self.flows.items() if now - f.last < FLOW_IDLE_TIMEOUT}
