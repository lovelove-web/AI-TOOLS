"""Lateral movement, data exfiltration, and baseline/anomaly detection."""
from __future__ import annotations

import statistics
from collections import defaultdict, deque

from ..constants import LATERAL_PORTS, SYN, Severity
from ..packets import is_private
from .base import Detector, Window

MIN_REMEMBER_BYTES = 10_000


class LateralDetector(Detector):
    name = "lateral"

    def __init__(self, cfg):
        super().__init__(cfg)
        self.hosts = defaultdict(lambda: Window(self.t["lateral_window"]))

    def process(self, p):
        if not p.is_tcp or p.flags & 0x3F != SYN or p.dport not in LATERAL_PORTS:
            return []
        if not (is_private(p.src) and is_private(p.dst)):
            return []
        w = self.hosts[(p.src, p.dport)]
        w.add(p.ts, p.dst)
        n = w.distinct()
        if n >= self.t["lateral_hosts"] and self.once((p.src, p.dport), p.ts, 300):
            svc = LATERAL_PORTS[p.dport]
            return [self.alert(p, "LAT-001", f"Lateral movement via {svc}", "lateral", Severity.HIGH,
                               f"Internal host {p.src} reached {n} peers over {svc} in "
                               f"{self.t['lateral_window']}s - worm / pass-the-hash / admin abuse",
                               "T1021", dst="multiple", hosts=n)]
        return []


class ExfilDetector(Detector):
    name = "exfil"

    def __init__(self, cfg):
        super().__init__(cfg)
        self.sent = defaultdict(lambda: Window(self.t["exfil_window"]))
        self.known_dst: dict[str, set] = defaultdict(set)

    def process(self, p):
        if p.is_arp or p.is_icmp or not is_private(p.src) or is_private(p.dst):
            return []
        key, t = (p.src, p.dst), self.t
        w = self.sent[key]
        w.add(p.ts, p.length)
        total = sum(w.values())
        if total >= t["exfil_bytes"] and self.once(key, p.ts, 300):
            return [self.alert(p, "EXF-001", "Large outbound data transfer", "exfiltration", Severity.HIGH,
                               f"{p.src} sent {total / 1e6:.1f} MB to {p.dst} in {t['exfil_window']}s",
                               "T1041", bytes=total)]
        if p.dst not in self.known_dst[p.src] and total >= t["exfil_new_dest_bytes"] \
                and self.once(("rare",) + key, p.ts, 300):
            return [self.alert(p, "EXF-003", "Large upload to rare destination", "exfiltration",
                               Severity.HIGH, f"{p.src} pushed {total / 1e6:.1f} MB to never-seen "
                               f"external host {p.dst}", "T1567", bytes=total)]
        if total > MIN_REMEMBER_BYTES:
            self.known_dst[p.src].add(p.dst)
        return []


class BaselineDetector(Detector):
    """Learns normal packets/sec, then flags z-score outliers."""
    name = "baseline"

    def __init__(self, cfg):
        super().__init__(cfg)
        self.bucket_start = self.started = None
        self.count = 0
        self.samples: deque = deque(maxlen=720)

    def process(self, p):
        if self.started is None:
            self.started = self.bucket_start = p.ts
        self.count += 1
        if p.ts - self.bucket_start < 1:
            return []
        pps, self.count, self.bucket_start = self.count, 0, p.ts
        t, out = self.t, []
        learning = p.ts - self.started < t["baseline_warmup_minutes"] * 60
        if not learning and len(self.samples) > 30:
            mean = statistics.fmean(self.samples)
            sd = statistics.pstdev(self.samples) or 1.0
            z = (pps - mean) / sd
            if z >= t["baseline_sigma"] and pps >= t["baseline_min_pps"] and self.once("rate", p.ts):
                out.append(self.alert(p, "ANO-001", "Traffic-rate anomaly vs baseline", "anomaly",
                                      Severity.MEDIUM, f"{pps} pkt/s vs normal {mean:.0f}±{sd:.0f} "
                                      f"(z={z:.1f})", "T1498", dst="network", pps=pps, z=round(z, 1)))
        if learning or not out:
            self.samples.append(pps)
        return out
