"""Detector registry."""
from .auth import BruteForceDetector
from .c2 import BeaconDetector, DnsDetector, TlsDetector
from .exploit import ExploitDetector
from .flood import FloodDetector
from .internal import BaselineDetector, ExfilDetector, LateralDetector
from .ml import MLDetector
from .policy import PolicyDetector
from .scan import ScanDetector
from .scan_tcp import TcpScanDetector
from .signatures import SignatureDetector


def build_detectors(cfg, db, intel):
    return [ScanDetector(cfg), TcpScanDetector(cfg), FloodDetector(cfg), BruteForceDetector(cfg),
            DnsDetector(cfg, intel), BeaconDetector(cfg), TlsDetector(cfg, intel), ExploitDetector(cfg),
            LateralDetector(cfg), ExfilDetector(cfg), PolicyDetector(cfg, intel), SignatureDetector(cfg),
            BaselineDetector(cfg), MLDetector(cfg, db)]
