"""DoS / DDoS detection."""
from __future__ import annotations

from collections import defaultdict

from ..constants import ETH_BROADCAST, ICMP_ECHO_REQUEST, LIMITED_BROADCAST, SYN, Severity
from .base import Detector, Window


class FloodDetector(Detector):
    name = "flood"

    def __init__(self, cfg):
        super().__init__(cfg)
        w = self.t["flood_window"]
        self.syn = defaultdict(lambda: Window(w))
        self.udp = defaultdict(lambda: Window(w))
        self.icmp = defaultdict(lambda: Window(w))
        self.http = defaultdict(lambda: Window(self.t["http_flood_window"]))
        self.amp = defaultdict(lambda: Window(self.t["dns_amp_window"]))
        self.bcast, self.bw = Window(w), Window(1)

    def process(self, p):
        out, t = [], self.t
        self.bw.add(p.ts, p.length)
        total = sum(self.bw.values())
        if total >= t["bandwidth_bytes_per_sec"] and self.once("bw", p.ts, 30):
            out.append(self.alert(p, "DOS-007", "Bandwidth spike", "dos", Severity.HIGH,
                                  f"{total / 1e6:.1f} MB/s on the monitored link", "T1498",
                                  dst="link", bytes_per_sec=total))
        if p.is_arp:
            return out
        if p.dst == LIMITED_BROADCAST or p.dst_mac == ETH_BROADCAST:
            self.bcast.add(p.ts)
            if len(self.bcast) >= t["broadcast_storm"] and self.once("bc", p.ts, 30):
                out.append(self.alert(p, "DOS-006", "Broadcast storm", "dos", Severity.HIGH,
                                      f"{len(self.bcast)} broadcast frames in {t['flood_window']}s",
                                      "T1498", dst="broadcast"))
        if p.is_tcp:
            out += self._tcp(p)
        elif p.is_udp:
            out += self._udp(p)
        elif p.is_icmp and p.icmp_type == ICMP_ECHO_REQUEST:
            w = self.icmp[p.dst]
            w.add(p.ts)
            if len(w) >= t["icmp_flood"] and self.once(("icmp", p.dst), p.ts, 30):
                out.append(self.alert(p, "DOS-003", "ICMP (ping) flood", "dos", Severity.HIGH,
                                      f"{len(w)} echo requests to {p.dst} in {t['flood_window']}s",
                                      "T1498.001", packets=len(w)))
        return out

    def _tcp(self, p):
        out, t = [], self.t
        if p.flags & 0x3F == SYN:
            w = self.syn[p.dst]
            w.add(p.ts, p.src)
            if len(w) >= t["syn_flood"] and self.once(("syn", p.dst), p.ts, 30):
                srcs = w.distinct()
                out.append(self.alert(p, "DOS-001", "TCP SYN flood", "dos", Severity.CRITICAL,
                                      f"{len(w)} SYNs to {p.dst} in {t['flood_window']}s from {srcs} "
                                      "source(s) - half-open connection exhaustion", "T1498.001",
                                      syns=len(w), sources=srcs))
        if p.meta.get("http_method"):
            w = self.http[(p.src, p.dst)]
            w.add(p.ts)
            if len(w) >= t["http_flood"] and self.once(("http", p.src, p.dst), p.ts, 30):
                out.append(self.alert(p, "DOS-004", "HTTP request flood", "dos", Severity.HIGH,
                                      f"{len(w)} HTTP requests from {p.src} in "
                                      f"{t['http_flood_window']}s", "T1499.002", requests=len(w)))
        return out

    def _udp(self, p):
        out, t = [], self.t
        if p.meta.get("dns_response") and p.length > t["dns_amp_size"]:
            w = self.amp[p.dst]
            w.add(p.ts, p.length)
            if len(w) >= t["dns_amp_responses"] and self.once(("amp", p.dst), p.ts, 30):
                out.append(self.alert(p, "DOS-005", "DNS amplification attack", "dos", Severity.CRITICAL,
                                      f"{len(w)} oversized DNS responses (>{t['dns_amp_size']}B) "
                                      f"hitting victim {p.dst}", "T1498.002", responses=len(w)))
        w = self.udp[p.dst]
        w.add(p.ts)
        if len(w) >= t["udp_flood"] and self.once(("udp", p.dst), p.ts, 30):
            out.append(self.alert(p, "DOS-002", "UDP flood", "dos", Severity.HIGH,
                                  f"{len(w)} UDP packets to {p.dst} in {t['flood_window']}s",
                                  "T1498.001", packets=len(w)))
        return out
