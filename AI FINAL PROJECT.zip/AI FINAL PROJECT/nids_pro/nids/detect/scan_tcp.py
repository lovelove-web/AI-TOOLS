"""TCP scans: SYN/connect, NULL, FIN, Xmas, ACK, slow scans, host sweeps."""
from __future__ import annotations

from collections import defaultdict

from ..constants import ACK, FIN, PSH, SERVICE_BY_PORT, SYN, URG, Severity
from .base import Detector, Window

STEALTH_COMBOS = (  # (predicate, rule, name, explanation, severity)
    (lambda f: f == 0, "SCN-002", "TCP NULL scan", "no flags set (nmap -sN)", Severity.HIGH),
    (lambda f: f & (FIN | PSH | URG) == (FIN | PSH | URG), "SCN-003", "TCP Xmas scan",
     "FIN+PSH+URG set (nmap -sX)", Severity.HIGH),
    (lambda f: f == FIN, "SCN-009", "TCP FIN scan", "lone FIN with no session (nmap -sF)", Severity.MEDIUM),
    (lambda f: f & SYN and f & FIN, "EXP-003", "Illegal SYN+FIN flags",
     "malformed flags used for OS fingerprinting / evasion", Severity.HIGH),
)


class TcpScanDetector(Detector):
    name = "tcp_scan"

    def __init__(self, cfg):
        super().__init__(cfg)
        w, slow = self.t["scan_window"], self.t["slow_scan_window"]
        self.syn = defaultdict(lambda: Window(w))
        self.slow = defaultdict(lambda: Window(slow))
        self.ack = defaultdict(lambda: Window(w))
        self.hosts = defaultdict(lambda: Window(w))

    def process(self, p):
        if not p.is_tcp:
            return []
        out, f = [], p.flags & 0x3F
        for pred, rule, name, why, sev in STEALTH_COMBOS:
            if pred(f):
                if self.once((rule, p.src, p.dst), p.ts, 30):
                    out.append(self.alert(p, rule, name, "recon", sev,
                                          f"{p.src} -> {p.dst}:{p.dport} {why}", "T1046", flags=f))
                break
        if f & SYN and not f & ACK:
            out += self._syn(p)
        elif f == ACK and not p.payload:
            out += self._ack(p)
        return out

    def _syn(self, p):
        out, t, pair = [], self.t, (p.src, p.dst)
        self.syn[pair].add(p.ts, p.dport)
        self.slow[pair].add(p.ts, p.dport)
        self.hosts[p.src].add(p.ts, p.dst)
        ports = self.syn[pair].distinct()
        if ports >= t["scan_ports"] and self.once(("syn", pair), p.ts):
            sample = sorted(set(self.syn[pair].values()))[:8]
            names = ", ".join(SERVICE_BY_PORT.get(x, str(x)) for x in sample)
            out.append(self.alert(p, "SCN-001", "TCP port scan (SYN/connect)", "recon", Severity.HIGH,
                                  f"{p.src} probed {ports} TCP ports on {p.dst} in {t['scan_window']}s "
                                  f"(nmap -sS/-sT). Probed: {names}", "T1046",
                                  ports=ports, sample_ports=sample))
        slow = self.slow[pair].distinct()
        if slow >= t["slow_scan_ports"] and ports < t["scan_ports"] and self.once(("slow", pair), p.ts, 600):
            out.append(self.alert(p, "SCN-010", "Slow / stealth port scan", "recon", Severity.HIGH,
                                  f"{p.src} touched {slow} ports on {p.dst} over "
                                  f"{t['slow_scan_window'] // 60} min (nmap -T0/-T1, randomized)",
                                  "T1046", ports=slow))
        n = self.hosts[p.src].distinct()
        if n >= t["scan_hosts"] and self.once(("hsweep", p.src), p.ts):
            out.append(self.alert(p, "SCN-011", "Network sweep (one source, many hosts)", "recon",
                                  Severity.HIGH, f"{p.src} contacted {n} hosts - horizontal scan",
                                  "T1046", dst="multiple", hosts=n))
        return out

    def _ack(self, p):
        w = self.ack[(p.src, p.dst)]
        w.add(p.ts, p.dport)
        n = w.distinct()
        if n >= self.t["ack_scan_ports"] and self.once(("ack", p.src, p.dst), p.ts):
            return [self.alert(p, "SCN-012", "TCP ACK scan (firewall mapping)", "recon", Severity.HIGH,
                               f"{p.src} sent bare ACKs to {n} ports on {p.dst} (nmap -sA)",
                               "T1046", ports=n)]
        return []
