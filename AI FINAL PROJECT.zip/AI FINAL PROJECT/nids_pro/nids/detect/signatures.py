"""Signature / DPI rules engine. Rules are regexes over payload, editable via rules.json."""
from __future__ import annotations

import json
import re
import urllib.parse
from dataclasses import dataclass
from pathlib import Path

from ..constants import DANGEROUS_UPLOAD_EXT, SCANNER_USER_AGENTS, Severity
from .base import Detector


@dataclass
class Rule:
    rule_id: str
    name: str
    category: str
    severity: Severity
    pattern: re.Pattern
    mitre: str = ""
    target: str = "http"      # http | payload
    enabled: bool = True


DEFAULT_RULES = [
    ("WEB-001", "SQL injection", "web", "HIGH", r"(?i)(union(\s|\+|/\*.*?\*/)+select|'\s*or\s*'?1'?\s*=\s*'?1|sleep\(\d+\)|benchmark\(|information_schema|;\s*drop\s+table|\bxp_cmdshell)", "T1190"),
    ("WEB-002", "Cross-site scripting (XSS)", "web", "MEDIUM", r"(?i)(<script\b|javascript:|onerror\s*=|onload\s*=|<svg[^>]+onload|document\.cookie)", "T1059.007"),
    ("WEB-003", "OS command injection", "web", "CRITICAL", r"(?i)(;|\||`|\$\()\s*(cat|ls|id|whoami|uname|wget|curl|nc|bash|sh|powershell|cmd(\.exe)?)\b", "T1059"),
    ("WEB-004", "Path traversal / LFI", "web", "HIGH", r"(?i)(\.\./|\.\.\\|%2e%2e%2f|%2e%2e/|\.\.%2f|/etc/passwd|/etc/shadow|boot\.ini|win\.ini)", "T1083"),
    ("WEB-005", "Web-shell activity", "web", "CRITICAL", r"(?i)(c99\.php|r57\.php|b374k|wso\.php|china\s*chopper|cmd=whoami|eval\(base64_decode|passthru\(|shell_exec\()", "T1505.003"),
    ("WEB-006", "Shellshock exploit", "web", "CRITICAL", r"\(\)\s*\{\s*:;\s*\}\s*;", "T1190"),
    ("WEB-007", "Log4Shell JNDI exploit", "web", "CRITICAL", r"(?i)\$\{jndi:(ldap|rmi|dns|ldaps)://", "T1190"),
    ("WEB-008", "Server-side request forgery probe", "web", "MEDIUM", r"(?i)(169\.254\.169\.254|metadata\.google\.internal|file:///)", "T1190"),
    ("MAL-001", "Reverse shell payload", "malware", "CRITICAL", r"(?i)(bash\s+-i\s*>&\s*/dev/tcp/|nc(\.exe)?\s+-e\s|/bin/sh\s+-i|python\s+-c\s+.import\s+socket|powershell.*-enc)", "T1059", ),
    ("MAL-002", "Executable download (PE/ELF)", "malware", "MEDIUM", r"^(MZ\x90\x00|\x7fELF)", "T1105"),
    ("MAL-003", "Metasploit / Meterpreter marker", "malware", "CRITICAL", r"(?i)(meterpreter|metsrv|stdapi_)", "T1105"),
    ("EXP-008", "EternalBlue-style SMB exploit", "exploit", "CRITICAL", r"\xffSMB\x72.{0,60}NT LM 0\.12.{0,200}\\\\.*IPC\$", "T1210"),
    ("EXP-009", "Nmap scripting engine probe", "recon", "MEDIUM", r"(?i)(nmap scripting engine|nmaplowercheck|/nice ports,/tri[ck]ni)", "T1595"),
]
PAYLOAD_RULES = {"MAL-001", "MAL-002", "MAL-003", "EXP-008", "EXP-009"}


def load_rules(path: str | None) -> list[Rule]:
    """Built-in rules, plus/overridden by a user JSON file (policy/rule management)."""
    rules = {}
    for rid, name, cat, sev, pat, mitre in DEFAULT_RULES:
        rules[rid] = Rule(rid, name, cat, Severity[sev], re.compile(pat, re.S),
                          mitre, "payload" if rid in PAYLOAD_RULES else "http")
    if path and Path(path).exists():
        for r in json.loads(Path(path).read_text(encoding="utf-8")):
            rules[r["rule_id"]] = Rule(r["rule_id"], r["name"], r.get("category", "custom"),
                                       Severity[r.get("severity", "MEDIUM")], re.compile(r["pattern"], re.S),
                                       r.get("mitre", ""), r.get("target", "payload"), r.get("enabled", True))
    return [r for r in rules.values() if r.enabled]


class SignatureDetector(Detector):
    name = "signature"

    def __init__(self, cfg):
        super().__init__(cfg)
        self.rules = load_rules(cfg.rules_file)

    def process(self, p):
        if not p.payload or not p.is_tcp and not p.is_udp:
            return []
        out = []
        http_text = ""
        if p.l7 == "HTTP":
            uri = urllib.parse.unquote_plus(p.meta.get("http_uri", ""))
            body = urllib.parse.unquote_plus(p.meta.get("http_body", ""))
            http_text = f"{uri} {body} {p.meta.get('http_ua', '')}"
            out += self._http_checks(p)
        raw = p.payload[:4096].decode("latin-1")
        for r in self.rules:
            text = http_text if r.target == "http" else raw
            if text and r.pattern.search(text) and self.once((r.rule_id, p.src, p.dst), p.ts, 30):
                m = r.pattern.search(text)
                out.append(self.alert(p, r.rule_id, r.name, r.category, r.severity,
                                      f"{p.src} -> {p.dst}:{p.dport} matched signature; "
                                      f"snippet: {m.group(0)[:60]!r}", r.mitre, snippet=m.group(0)[:100],
                                      uri=p.meta.get("http_uri", "")[:120]))
        return out

    def _http_checks(self, p):
        out = []
        ua = p.meta.get("http_ua", "").lower()
        hit = next((s for s in SCANNER_USER_AGENTS if s in ua), None)
        if hit and self.once(("ua", p.src, hit), p.ts, 120):
            out.append(self.alert(p, "WEB-009", f"Attack-tool user agent ({hit})", "web", Severity.HIGH,
                                  f"{p.src} is using '{hit}' against {p.meta.get('http_host', p.dst)}",
                                  "T1595.002", user_agent=ua[:100]))
        if p.meta.get("http_method") in ("POST", "PUT") and any(
                e in p.payload.lower() for e in (b'filename="' + x.encode() for x in DANGEROUS_UPLOAD_EXT)) \
                and self.once(("upl", p.src, p.dst), p.ts, 60):
            out.append(self.alert(p, "WEB-010", "Malicious file upload attempt", "web", Severity.HIGH,
                                  f"{p.src} uploaded an executable/script file to {p.dst}", "T1505.003"))
        return out
