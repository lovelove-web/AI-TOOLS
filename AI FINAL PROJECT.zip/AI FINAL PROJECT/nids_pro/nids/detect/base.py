"""Detector base class and sliding-window helper."""
from __future__ import annotations

from collections import deque

from ..alerts import Alert
from ..constants import DEFAULT_RULE_CONFIDENCE
from ..packets import PacketInfo


class Window:
    """Sliding time window of (timestamp, value)."""

    def __init__(self, seconds: float):
        self.seconds = seconds
        self.items: deque = deque()

    def add(self, ts: float, value=None) -> None:
        self.items.append((ts, value))
        while self.items and ts - self.items[0][0] > self.seconds:
            self.items.popleft()

    def values(self) -> list:
        return [v for _, v in self.items]

    def distinct(self) -> int:
        return len(set(self.values()))

    def __len__(self) -> int:
        return len(self.items)


class Detector:
    name = "base"

    def __init__(self, cfg):
        self.cfg = cfg
        self.t = cfg.thresholds
        self.enabled = True          # toggled from the dashboard
        self._fired: dict = {}

    def process(self, pkt: PacketInfo) -> list[Alert]:
        raise NotImplementedError

    def once(self, key, ts: float, gap: float = 60) -> bool:
        """Rate-limit: True only if `key` has not fired within `gap` seconds."""
        if ts - self._fired.get(key, 0) < gap:
            return False
        self._fired[key] = ts
        return True

    def housekeeping(self, now: float) -> None:
        self._fired = {k: v for k, v in self._fired.items() if now - v < 3600}

    @staticmethod
    def alert(pkt, rule, name, cat, sev, desc, mitre="", dst=None, **evidence) -> Alert:
        """Build an alert. A `confidence=` kwarg (ML model) overrides the rule heuristic."""
        conf = evidence.pop("confidence", None)
        evidence["confidence_source"] = "ml-model" if conf is not None else "rule-heuristic"
        return Alert(rule, name, cat, sev, pkt.src, dst or pkt.dst, desc, mitre, evidence,
                     ts=pkt.ts, sport=pkt.sport, dport=pkt.dport, protocol=pkt.label(),
                     confidence=DEFAULT_RULE_CONFIDENCE if conf is None else conf,
                     details=pkt.describe(), packet=pkt.raw)
