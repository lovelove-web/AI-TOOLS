"""Policy violations, non-standard ports, cleartext credentials, threat-intel IP hits."""
from __future__ import annotations

import ipaddress

from ..constants import ACK, BANNED_PORTS, SYN, Severity
from ..protocols import is_nonstandard_port
from .base import Detector

CLEARTEXT_MARKERS = (b"PASS ", b"Authorization: Basic")


class PolicyDetector(Detector):
    name = "policy"

    def __init__(self, cfg, intel=None):
        super().__init__(cfg)
        self.intel = intel
        self.restricted = [ipaddress.ip_network(n, strict=False) for n in cfg.restricted_networks]

    def process(self, p):
        if p.is_arp:
            return []
        out = []
        flags = p.flags & 0x3F
        if p.is_tcp and flags == SYN and p.dport in BANNED_PORTS \
                and self.once(("ban", p.src, p.dst, p.dport), p.ts, 300):
            out.append(self.alert(p, "POL-001", "Banned protocol / service", "policy", Severity.MEDIUM,
                                  f"{p.src} -> {p.dst}:{p.dport} {BANNED_PORTS[p.dport]}", "T1219",
                                  port=p.dport))
        if p.is_tcp and flags == SYN | ACK:
            allowed = self.cfg.allowed_services.get(p.src)
            if allowed is not None and p.sport not in allowed and self.once(("shadow", p.src, p.sport), p.ts, 300):
                out.append(self.alert(p, "POL-002", "Unauthorized service (shadow IT)", "policy",
                                      Severity.MEDIUM, f"{p.src} listens on unapproved port {p.sport}",
                                      "T1543", port=p.sport))
        if self.restricted and self._restricted(p.dst) and self.once(("rest", p.src, p.dst), p.ts, 300):
            out.append(self.alert(p, "POL-003", "Traffic to restricted destination", "policy", Severity.HIGH,
                                  f"{p.src} contacted restricted address {p.dst}", "T1071"))
        if is_nonstandard_port(p) and self.once(("nsp", p.src, p.dst, p.dport, p.l7), p.ts, 300):
            out.append(self.alert(p, "POL-004", f"{p.l7} on non-standard port", "policy", Severity.MEDIUM,
                                  f"{p.l7} traffic on port {p.dport} ({p.src} -> {p.dst}) - possible "
                                  "tunnelling or hidden service", "T1571", protocol=p.l7))
        if p.l7 in ("FTP", "HTTP", "SMTP") and any(m in p.payload[:200] for m in CLEARTEXT_MARKERS) \
                and self.once(("clr", p.src, p.dst), p.ts, 60):
            out.append(self.alert(p, "POL-005", "Cleartext credentials on the wire", "policy",
                                  Severity.MEDIUM, f"{p.l7} login sent unencrypted {p.src} -> {p.dst}",
                                  "T1552", protocol=p.l7))
        if self.intel and self.intel.is_bad_ip(p.dst) and self.once(("tiip", p.src, p.dst), p.ts, 300):
            out.append(self.alert(p, "TI-001", "Connection to known-malicious IP", "c2", Severity.CRITICAL,
                                  f"{p.src} talked to {p.dst} (threat-intel blocklist)", "T1071"))
        return out

    def _restricted(self, ip: str) -> bool:
        try:
            addr = ipaddress.ip_address(ip)
        except ValueError:
            return False
        return any(addr in n for n in self.restricted)
