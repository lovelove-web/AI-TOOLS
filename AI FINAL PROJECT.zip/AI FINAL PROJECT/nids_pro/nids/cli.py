"""Command-line interface."""
from __future__ import annotations

import argparse
import json
import shutil
import sys
import time
from pathlib import Path

from .config import Config
from .detect.ml import import_pickle
from .engine import Engine
from .storage import Database
from .web import start_dashboard


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="nids", description="Professional Network Intrusion Detection System")
    ap.add_argument("-c", "--config", help="JSON config file")
    sub = ap.add_subparsers(dest="cmd", required=True)
    run = sub.add_parser("run", help="live monitoring")
    run.add_argument("-i", "--interface", action="append", help="interface (repeat for several)")
    run.add_argument("--mode", choices=("ids", "ips"))
    run.add_argument("--quiet", action="store_true")
    run.add_argument("--standby", action="store_true",
                     help="start the dashboard but wait for the Start button before capturing")
    rep = sub.add_parser("replay", help="analyse a PCAP offline")
    rep.add_argument("pcap")
    sub.add_parser("interfaces", help="list capture interfaces")
    imp = sub.add_parser("import-model", help="import legacy .pkl model (trusted files only)")
    imp.add_argument("pkl")
    sub.add_parser("alerts", help="show recent alerts").add_argument("-n", type=int, default=20)
    sub.add_parser("actions", help="list pending response actions")
    for name in ("approve", "reject"):
        sub.add_parser(name, help=f"{name} a queued response action").add_argument("id", type=int)
    sub.add_parser("report", help="summary report of stored alerts")
    sub.add_parser("backup", help="back up config + database")
    return ap


def cmd_alerts(db, n):
    for a in reversed(db.query("SELECT * FROM alerts ORDER BY id DESC LIMIT ?", (n,))):
        print(f"{time.strftime('%F %T', time.localtime(a['ts']))} [{a['severity']:<8}] {a['name']} "
              f"({a['rule_id']}) {a['src']} -> {a['dst']}: {a['description']}")


def cmd_report(db):
    print("== Alerts by severity ==")
    for r in db.query("SELECT severity, COUNT(*) n FROM alerts GROUP BY severity ORDER BY n DESC"):
        print(f"  {r['severity']:<9}{r['n']}")
    print("== Top detections ==")
    for r in db.query("SELECT name, COUNT(*) n FROM alerts GROUP BY name ORDER BY n DESC LIMIT 10"):
        print(f"  {r['n']:>5}  {r['name']}")
    print("== Top sources ==")
    for r in db.query("SELECT src, COUNT(*) n FROM alerts GROUP BY src ORDER BY n DESC LIMIT 10"):
        print(f"  {r['n']:>5}  {r['src']}")


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    cfg = Config.load(args.config)
    if args.cmd == "interfaces":
        from scapy.all import get_if_list
        print("\n".join(get_if_list()))
        return 0
    if args.cmd == "backup":
        dest = Path("backup") / time.strftime("%Y%m%d-%H%M%S")
        dest.mkdir(parents=True, exist_ok=True)
        for f in filter(None, (args.config, cfg.db_file, cfg.rules_file)):
            if Path(f).exists():
                shutil.copy2(f, dest)
        print(f"Backup written to {dest}")
        return 0
    if args.cmd in ("alerts", "report", "actions", "import-model"):
        db = Database(cfg.db_file)
        if args.cmd == "alerts":
            cmd_alerts(db, args.n)
        elif args.cmd == "report":
            cmd_report(db)
        elif args.cmd == "actions":
            print(json.dumps(db.query("SELECT * FROM actions ORDER BY id DESC LIMIT 50"), indent=2))
        else:
            import_pickle(db, args.pkl)
            print(f"[+] Imported {args.pkl}")
        return 0
    if args.cmd in ("approve", "reject"):
        eng = Engine(cfg, quiet=True)
        print(eng.response.decide(args.id, args.cmd == "approve", "cli-analyst"))
        return 0
    if args.cmd == "replay":
        eng = Engine(cfg)
        eng.replay(args.pcap)
        eng.stop()
        return 0
    if args.interface:
        cfg.interfaces = args.interface
    if args.mode:
        cfg.mode = args.mode
    eng = Engine(cfg, quiet=args.quiet)
    start_dashboard(eng, cfg)
    print(f"[*] NIDS {cfg.mode.upper()} mode, {len(eng.detectors)} detectors, "
          f"interface(s): {cfg.interfaces or 'default'}. Ctrl+C to stop.")
    try:
        if args.standby:
            eng.start_worker()
            print("[*] Standby: press 'Start monitoring' in the dashboard to begin capture.")
            eng.wait_forever()
        else:
            eng.run_live()
    finally:
        eng.stop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
