"""Configuration loading (JSON file merged over safe defaults)."""
from __future__ import annotations

import ipaddress
import json
from dataclasses import dataclass, field, fields
from pathlib import Path
from typing import Any

from .constants import DEFAULT_DB, DEFAULT_LOG_DIR, DEFAULT_THRESHOLDS


@dataclass
class Config:
    interfaces: list[str] = field(default_factory=list)
    bpf_filter: str = ""
    monitored_ips: list[str] = field(default_factory=list)   # empty = everything
    home_networks: list[str] = field(default_factory=lambda: ["192.168.0.0/16", "10.0.0.0/8", "172.16.0.0/12"])
    ignore_ips: list[str] = field(default_factory=list)
    never_block: list[str] = field(default_factory=list)
    allowed_services: dict[str, list[int]] = field(default_factory=dict)  # host -> ports (shadow-IT check)
    restricted_networks: list[str] = field(default_factory=list)
    db_file: str = DEFAULT_DB
    log_dir: str = DEFAULT_LOG_DIR
    pcap_all: str = ""          # full capture file ("" = disabled)
    pcap_evidence: bool = True  # save packet that triggered an alert
    mode: str = "ids"           # "ids" (alert only) or "ips" (queue blocks for approval)
    min_notify_severity: str = "MEDIUM"
    thresholds: dict[str, Any] = field(default_factory=lambda: dict(DEFAULT_THRESHOLDS))
    ml_labels: dict[str, str] = field(default_factory=dict)   # e.g. {"1": "DoS attack"}
    threat_intel_files: list[str] = field(default_factory=list)  # IP/domain lists (path or http URL)
    bad_ja3: list[str] = field(default_factory=list)
    rules_file: str = "rules.json"
    notifications: dict[str, Any] = field(default_factory=dict)  # slack/teams/webhook/email/syslog
    dashboard: dict[str, Any] = field(default_factory=lambda: {
        "enabled": False, "host": "127.0.0.1", "port": 8080,
        "tokens": {}})  # token -> viewer|analyst|admin

    def home_nets(self):
        return [ipaddress.ip_network(n, strict=False) for n in self.home_networks]

    @classmethod
    def load(cls, path: str | None) -> "Config":
        cfg = cls()
        if not path:
            return cfg
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        known = {f.name for f in fields(cls)}
        unknown = set(data) - known
        if unknown:
            raise ValueError(f"Unknown config keys: {sorted(unknown)}")
        for key, value in data.items():
            if key == "thresholds":
                cfg.thresholds.update(value)
            elif key == "dashboard":
                cfg.dashboard.update(value)
            else:
                setattr(cfg, key, value)
        if cfg.mode not in ("ids", "ips"):
            raise ValueError("mode must be 'ids' or 'ips'")
        return cfg
