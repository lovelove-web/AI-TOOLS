"""Thread-safe live traffic statistics for the dashboard charts."""
from __future__ import annotations

import threading
import time
from collections import Counter, deque

from .constants import (RECENT_PACKET_BUFFER, STATS_HISTORY_SECONDS, STATS_MAX_TRACKED,
                        STATS_TOP_N, SYN)
from .packets import PacketInfo


class TrafficStats:
    def __init__(self):
        self._lock = threading.Lock()
        self.reset()

    def reset(self) -> None:
        with self._lock:
            self.total_packets = 0
            self.total_bytes = 0
            self.protocols: Counter = Counter()
            self.talkers: Counter = Counter()           # src -> bytes
            self.target_ports: Counter = Counter()      # dst port -> SYN/UDP attempts
            self.series: deque = deque(maxlen=STATS_HISTORY_SECONDS)   # (second, pkts, bytes)
            self._cur_sec = 0
            self._cur_pkts = self._cur_bytes = 0
            self.recent: deque = deque(maxlen=RECENT_PACKET_BUFFER)   # decoded packets for drill-down

    def add(self, p: PacketInfo) -> None:
        sec = int(p.ts)
        with self._lock:
            self.total_packets += 1
            self.total_bytes += p.length
            self.protocols[p.label()] += 1
            self.talkers[p.src] += p.length
            if p.dport and (p.is_udp or (p.is_tcp and p.flags & 0x3F == SYN)):
                self.target_ports[p.dport] += 1
            if sec != self._cur_sec:
                if self._cur_sec:
                    self.series.append((self._cur_sec, self._cur_pkts, self._cur_bytes))
                self._cur_sec, self._cur_pkts, self._cur_bytes = sec, 0, 0
            self._cur_pkts += 1
            self._cur_bytes += p.length
            self.recent.append(p)
            for counter in (self.talkers, self.target_ports, self.protocols):
                if len(counter) > STATS_MAX_TRACKED:      # bound memory under scans/floods
                    for key, _ in counter.most_common()[STATS_MAX_TRACKED // 2:]:
                        del counter[key]

    def related(self, src: str, dst: str, around: float, limit: int) -> list[dict]:
        """Recent packets between the two hosts closest in time to `around`."""
        with self._lock:
            hits = [p for p in self.recent if {p.src, p.dst} == {src, dst} or p.src == src]
        hits.sort(key=lambda p: abs(p.ts - around))
        return [p.describe() for p in sorted(hits[:limit], key=lambda p: p.ts)]

    def snapshot(self) -> dict:
        with self._lock:
            series = list(self.series)[-STATS_HISTORY_SECONDS:]
            return {
                "total_packets": self.total_packets,
                "total_bytes": self.total_bytes,
                "series": [{"t": t, "pps": n, "bps": b} for t, n, b in series],
                "protocols": [{"name": k, "count": v} for k, v in self.protocols.most_common(STATS_TOP_N)],
                "top_talkers": [{"ip": k, "bytes": v} for k, v in self.talkers.most_common(STATS_TOP_N)],
                "top_ports": [{"port": k, "count": v} for k, v in self.target_ports.most_common(STATS_TOP_N)],
                "generated": time.time(),
            }
