"""Traffic collection: multi-interface live sniffing (SPAN/mirror/TAP ports), PCAP replay."""
from __future__ import annotations

import time

from scapy.all import AsyncSniffer, PcapReader, conf, get_if_list

from .constants import CAPTURE_START_GRACE


def list_interfaces() -> list[dict]:
    """Interfaces usable for capture, with human-readable names (important on Windows/Npcap)."""
    found = []
    try:
        for iface in conf.ifaces.values():
            found.append({"id": iface.network_name or iface.name, "name": iface.name,
                          "description": getattr(iface, "description", "") or "",
                          "ip": getattr(iface, "ip", "") or ""})
    except Exception:                     # fall back to the plain scapy list
        found = [{"id": n, "name": n, "description": "", "ip": ""} for n in get_if_list()]
    return found


class Capture:
    def __init__(self, interfaces: list[str], bpf_filter: str, callback):
        self.interfaces = interfaces or [None]     # None = scapy default interface
        self.bpf = bpf_filter or None
        self.callback = callback
        self.sniffers: list[AsyncSniffer] = []

    def start(self) -> None:
        """Start sniffing. Raises RuntimeError if an interface cannot be opened."""
        known = {i["id"] for i in list_interfaces()} | set(get_if_list())
        for iface in self.interfaces:
            if iface and iface not in known:
                raise ValueError(f"Interface {iface!r} not found")
        try:
            for iface in self.interfaces:
                # promiscuous mode is scapy's default - required for SPAN/mirror/TAP feeds
                sniffer = AsyncSniffer(iface=iface, prn=self.callback, store=False, filter=self.bpf)
                sniffer.start()
                self.sniffers.append(sniffer)
            deadline = time.time() + CAPTURE_START_GRACE
            while time.time() < deadline:
                if all(getattr(s, "running", False) for s in self.sniffers):
                    return
                time.sleep(0.1)
            dead = [s for s in self.sniffers if not getattr(s, "running", False)]
            if dead:
                raise RuntimeError("capture failed to start (run as Administrator/root and check "
                                   "that Npcap/libpcap is installed)")
        except Exception:
            self.stop()
            raise

    def stop(self) -> None:
        for s in self.sniffers:
            try:
                if getattr(s, "running", False):
                    s.stop()
            except Exception:       # sniffer may already be stopped
                pass
        self.sniffers = []

    @property
    def running(self) -> bool:
        return bool(self.sniffers) and all(getattr(s, "running", False) for s in self.sniffers)

    @staticmethod
    def replay(pcap_path: str, callback) -> None:
        with PcapReader(pcap_path) as reader:
            for raw in reader:
                callback(raw)
