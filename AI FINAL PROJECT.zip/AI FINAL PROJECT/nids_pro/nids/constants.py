"""Shared constants. No magic numbers should live anywhere else."""
from enum import IntEnum

APP_NAME = "nids"
DEFAULT_DB = "nids_lab.db"
DEFAULT_LOG_DIR = "logs"


class Severity(IntEnum):
    INFO = 0
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


# TCP flag bits
FIN, SYN, RST, PSH, ACK, URG = 0x01, 0x02, 0x04, 0x08, 0x10, 0x20
XMAS_MASK = FIN | PSH | URG

# ICMP types
ICMP_ECHO_REPLY, ICMP_ECHO_REQUEST = 0, 8
ICMP_TIMESTAMP_REQUEST, ICMP_ADDRMASK_REQUEST = 13, 17

IP_PROTO_ICMP, IP_PROTO_TCP, IP_PROTO_UDP = 1, 6, 17
ETH_BROADCAST = "ff:ff:ff:ff:ff:ff"
LIMITED_BROADCAST = "255.255.255.255"

# Well-known ports per protocol (used for non-standard-port detection)
STANDARD_PORTS = {
    "HTTP": {80, 8080, 8000, 8008, 8888},
    "TLS": {443, 8443, 993, 995, 465, 636, 8883},
    "SSH": {22},
    "FTP": {21},
    "SMTP": {25, 587, 465},
    "DNS": {53, 5353},
    "DHCP": {67, 68},
    "SMB": {445, 139},
    "MQTT": {1883, 8883},
    "RDP": {3389},
    "TELNET": {23},
}
SERVICE_BY_PORT = {
    21: "FTP", 22: "SSH", 23: "TELNET", 25: "SMTP", 53: "DNS", 67: "DHCP",
    80: "HTTP", 110: "POP3", 143: "IMAP", 443: "TLS", 445: "SMB", 587: "SMTP",
    993: "IMAPS", 1433: "MSSQL", 1883: "MQTT", 3306: "MySQL", 3389: "RDP",
    5432: "PostgreSQL", 5900: "VNC", 5985: "WinRM", 8883: "MQTT-TLS",
}
AUTH_PORTS = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP-AUTH", 110: "POP3",
    143: "IMAP", 445: "SMB", 587: "SMTP-AUTH", 1194: "OpenVPN", 1433: "MSSQL",
    3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL", 5900: "VNC", 5985: "WinRM",
}
LATERAL_PORTS = {445: "SMB", 139: "SMB", 3389: "RDP", 5985: "WinRM", 5986: "WinRM", 22: "SSH"}
BANNED_PORTS = {
    23: "Telnet (cleartext remote shell)",
    69: "TFTP (unauthenticated file transfer)",
    5938: "TeamViewer (unapproved remote access)",
    7070: "AnyDesk (unapproved remote access)",
    5900: "VNC (unapproved remote access)",
    6667: "IRC (common botnet C2)", 6668: "IRC", 6669: "IRC",
    9001: "Tor OR port", 9030: "Tor directory port",
}

HTTP_METHODS = (b"GET ", b"POST ", b"PUT ", b"DELETE ", b"HEAD ", b"OPTIONS ", b"PATCH ")
SCANNER_USER_AGENTS = (
    "sqlmap", "nikto", "nmap scripting engine", "masscan", "gobuster", "dirbuster",
    "dirb", "wpscan", "hydra", "zgrab", "nuclei", "acunetix", "burp", "havij",
)
DANGEROUS_UPLOAD_EXT = (".php", ".phtml", ".jsp", ".jspx", ".asp", ".aspx", ".exe", ".sh", ".war")

DEFAULT_THRESHOLDS = {
    # window = seconds, others = event counts
    "scan_window": 30, "scan_ports": 15, "scan_hosts": 10,
    "slow_scan_window": 3600, "slow_scan_ports": 25,
    "ack_scan_ports": 10, "udp_scan_ports": 10, "arp_sweep_hosts": 15,
    "ping_sweep_hosts": 5, "alert_on_single_ping": True,
    "flood_window": 5, "syn_flood": 200, "udp_flood": 300, "icmp_flood": 100,
    "http_flood_window": 10, "http_flood": 100,
    "dns_amp_window": 10, "dns_amp_responses": 20, "dns_amp_size": 512,
    "broadcast_storm": 200, "bandwidth_bytes_per_sec": 50_000_000,
    "bruteforce_window": 60, "bruteforce_attempts": 10, "web_login_attempts": 15,
    "frag_window": 10, "frag_count": 50, "icmp_oversize": 1000,
    "dns_label_entropy": 3.8, "dns_label_len": 24, "dns_qname_len": 60,
    "dns_volume_window": 60, "dns_unique_names": 200, "dns_txt_count": 30,
    "beacon_min_events": 8, "beacon_max_cv": 0.10, "beacon_min_interval": 2.0,
    "exfil_window": 300, "exfil_bytes": 50_000_000, "exfil_new_dest_bytes": 10_000_000,
    "lateral_window": 300, "lateral_hosts": 5,
    "baseline_warmup_minutes": 10, "baseline_sigma": 4.0, "baseline_min_pps": 200,
    "ml_confidence": 0.60,
}

CLEARTEXT_CREDENTIAL_MARKERS = (b"PASS ", b"Authorization: Basic")
BENIGN_LABELS = {"0", "normal", "benign", "safe", "normal traffic"}

FEATURE_NAMES = [
    "avg_ipt", "bytes_in", "bytes_out", "dest_ip", "dest_port",
    "duration", "entropy", "num_pkts_in", "num_pkts_out", "proto",
    "src_ip", "src_port", "time_end", "time_start", "total_entropy",
]
ML_CHECKPOINTS = frozenset({1, 2, 3, 5, 10, 20, 50})
ML_CHECKPOINT_EVERY = 100
FLOW_HISTORY_LIMIT = 500
FLOW_IDLE_TIMEOUT = 120
HOUSEKEEPING_INTERVAL = 30
DEDUP_COOLDOWN = 60
CORRELATION_WINDOW = 300
CORRELATION_MIN_CATEGORIES = 3

# --- dashboard / runtime -------------------------------------------------------
PROTO_NAMES = {1: "ICMP", 6: "TCP", 17: "UDP"}
PAYLOAD_PREVIEW_BYTES = 96
RELATED_PACKETS = 20
RECENT_PACKET_BUFFER = 3000
DEFAULT_RULE_CONFIDENCE = 0.85      # heuristic score for rule-based alerts (ML alerts use the model's)
STATS_HISTORY_SECONDS = 300
STATS_TOP_N = 8
STATS_MAX_TRACKED = 5000
CAPTURE_QUEUE_SIZE = 20000
HEARTBEAT_INTERVAL = 5
CAPTURE_START_GRACE = 1.5
MAX_REQUEST_BYTES = 65536
ALERT_STATUSES = ("new", "acknowledged", "investigating", "resolved")
MAX_NOTE_LENGTH = 1000
MAX_CUSTOM_PATTERN = 300
MAX_ALERT_PAGE = 500
FILE_COMMANDS = (b"STOR ", b"RETR ")
SERVICE_PROTOS = frozenset({"HTTP", "TLS", "SSH", "SMTP", "FTP", "SMB", "MQTT", "RDP"})
PRIVILEGED_PORT_MAX = 1024
