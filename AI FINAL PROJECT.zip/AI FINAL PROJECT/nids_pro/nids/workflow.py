"""Alert triage workflow: filtered queries, status changes, analyst notes."""
from __future__ import annotations

import json
import time

from .constants import ALERT_STATUSES, MAX_ALERT_PAGE, MAX_NOTE_LENGTH, Severity

TIMELINE_DEFAULT_SECONDS = 3600

JSON_COLUMNS = ("evidence", "details", "notes")


def _hydrate(row: dict) -> dict:
    for col in JSON_COLUMNS:
        try:
            row[col] = json.loads(row.get(col) or ("[]" if col == "notes" else "{}"))
        except (TypeError, ValueError):
            row[col] = [] if col == "notes" else {}
    return row


def query_alerts(db, severity: str = "", status: str = "", text: str = "", since: float = 0,
                 category: str = "", limit: int = 100, offset: int = 0, full: bool = False) -> list[dict]:
    """Filtered alert list. `severity` may be a comma list, e.g. 'CRITICAL,HIGH'."""
    where, params = ["1=1"], []
    if severity:
        names = [s for s in severity.upper().split(",") if s in Severity.__members__]
        if names:
            where.append(f"severity IN ({','.join('?' * len(names))})")
            params += names
    if status in ALERT_STATUSES:
        where.append("status = ?")
        params.append(status)
    if category:
        where.append("category = ?")
        params.append(category)
    if since:
        where.append("ts >= ?")
        params.append(since)
    if text:
        like = f"%{text}%"
        where.append("(name LIKE ? OR src LIKE ? OR dst LIKE ? OR rule_id LIKE ? OR description LIKE ?)")
        params += [like] * 5
    limit = max(1, min(limit, MAX_ALERT_PAGE))
    cols = "*" if full else ("id, ts, rule_id, name, category, severity, src, dst, sport, dport, "
                             "protocol, confidence, count, status, mitre, description, updated_by, updated_at")
    rows = db.query(f"SELECT {cols} FROM alerts WHERE {' AND '.join(where)} "
                    f"ORDER BY id DESC LIMIT ? OFFSET ?", (*params, limit, max(0, offset)))
    return [_hydrate(r) for r in rows] if full else rows


def get_alert(db, alert_id: int) -> dict | None:
    rows = db.query("SELECT * FROM alerts WHERE id = ?", (alert_id,))
    return _hydrate(rows[0]) if rows else None


def update_alert(db, alert_id: int, status: str | None, note: str | None, actor: str) -> dict:
    """Set the triage status and/or append a response note. Every change is audited."""
    alert = get_alert(db, alert_id)
    if alert is None:
        raise KeyError(alert_id)
    if status is not None and status not in ALERT_STATUSES:
        raise ValueError(f"status must be one of {ALERT_STATUSES}")
    now = time.time()
    notes = alert["notes"]
    note = (note or "").strip()[:MAX_NOTE_LENGTH]
    if note:
        notes.append({"ts": now, "by": actor, "text": note, "status": status or alert["status"]})
    new_status = status or alert["status"]
    db.execute("UPDATE alerts SET status=?, notes=?, updated_at=?, updated_by=? WHERE id=?",
               (new_status, json.dumps(notes), now, actor, alert_id))
    db.audit(actor, "alert_update", f"alert={alert_id} status={new_status} note={'yes' if note else 'no'}")
    return get_alert(db, alert_id)


def summary(db, since: float = 0) -> dict:
    """Counts used by the summary cards, attack widgets and tables."""
    cond, params = ("WHERE ts >= ?", (since,)) if since else ("", ())
    sev = {r["severity"]: r["n"] for r in db.query(
        f"SELECT severity, COUNT(*) n FROM alerts {cond} GROUP BY severity", params)}
    status = {r["status"]: r["n"] for r in db.query(
        f"SELECT status, COUNT(*) n FROM alerts {cond} GROUP BY status", params)}
    cats = db.query(f"SELECT category, COUNT(*) n FROM alerts {cond} GROUP BY category ORDER BY n DESC", params)
    top_rules = db.query(f"SELECT rule_id, name, severity, COUNT(*) n, MAX(ts) last FROM alerts {cond} "
                         "GROUP BY rule_id ORDER BY n DESC LIMIT 10", params)
    top_src = db.query(f"SELECT src, COUNT(*) n, MAX(severity) worst FROM alerts {cond} "
                       "GROUP BY src ORDER BY n DESC LIMIT 8", params)
    top_dst = db.query(f"SELECT dst, COUNT(*) n FROM alerts {cond} GROUP BY dst ORDER BY n DESC LIMIT 8", params)
    timeline = db.query("SELECT CAST(ts/60 AS INT)*60 AS bucket, severity, COUNT(*) n FROM alerts "
                        "WHERE ts >= ? GROUP BY bucket, severity ORDER BY bucket",
                        (since or time.time() - TIMELINE_DEFAULT_SECONDS,))
    return {"severity": sev, "status": status, "categories": cats, "top_rules": top_rules,
            "top_sources": top_src, "top_targets": top_dst, "timeline": timeline,
            "total": sum(sev.values()), "open": sum(n for s, n in status.items() if s != "resolved")}
