"""Threat-intelligence feed loader (local files or http(s) URLs; one IP/CIDR/domain per line)."""
from __future__ import annotations

import ipaddress
import urllib.request
from pathlib import Path


class ThreatIntel:
    def __init__(self, sources: list[str]):
        self.ips: set[str] = set()
        self.nets: list = []
        self.domains: set[str] = set()
        for s in sources:
            try:
                self._load(s)
            except Exception as exc:
                print(f"[!] threat-intel source {s} failed: {exc}")

    def _load(self, source: str) -> None:
        if source.startswith(("http://", "https://")):
            text = urllib.request.urlopen(source, timeout=15).read().decode(errors="replace")
        else:
            text = Path(source).read_text(encoding="utf-8")
        for line in text.splitlines():
            entry = line.split("#")[0].strip().lower()
            if not entry:
                continue
            try:
                if "/" in entry:
                    self.nets.append(ipaddress.ip_network(entry, strict=False))
                else:
                    self.ips.add(str(ipaddress.ip_address(entry)))
            except ValueError:
                self.domains.add(entry)

    def is_bad_ip(self, ip: str) -> bool:
        if ip in self.ips:
            return True
        try:
            addr = ipaddress.ip_address(ip)
        except ValueError:
            return False
        return any(addr in n for n in self.nets)

    def is_bad_domain(self, name: str) -> bool:
        parts = name.lower().rstrip(".").split(".")
        return any(".".join(parts[i:]) in self.domains for i in range(len(parts)))

    def __len__(self) -> int:
        return len(self.ips) + len(self.nets) + len(self.domains)
