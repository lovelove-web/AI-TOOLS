"""Alert export: CSV, JSON and a dependency-free PDF incident report."""
from __future__ import annotations

import csv
import io
import json
import time

PDF_PAGE_W, PDF_PAGE_H, PDF_MARGIN, PDF_LINE = 595, 842, 40, 13
PDF_MAX_CHARS = 100
CSV_FIELDS = ["id", "ts", "time", "severity", "name", "rule_id", "category", "src", "sport", "dst", "dport",
              "protocol", "confidence", "count", "status", "mitre", "description"]


def _fmt(ts) -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(float(ts or 0)))


def to_csv(alerts: list[dict]) -> bytes:
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=CSV_FIELDS, extrasaction="ignore")
    writer.writeheader()
    for a in alerts:
        # neutralise spreadsheet formula injection (=, +, -, @) in attacker-controlled text
        row = {k: (("'" + v) if isinstance(v, str) and v[:1] in "=+-@" else v) for k, v in a.items()}
        row["time"] = _fmt(a["ts"])
        writer.writerow(row)
    return buf.getvalue().encode("utf-8-sig")        # BOM so Excel opens UTF-8 correctly


def to_json(alerts: list[dict]) -> bytes:
    return json.dumps({"generated": _fmt(time.time()), "count": len(alerts), "alerts": alerts},
                      indent=2, default=str).encode()


def _pdf_escape(text: str) -> str:
    text = text.encode("latin-1", "replace").decode("latin-1")
    return text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def _wrap(text: str, width: int = PDF_MAX_CHARS) -> list[str]:
    lines = []
    for raw in str(text).splitlines() or [""]:
        while len(raw) > width:
            cut = raw.rfind(" ", 0, width)
            cut = cut if cut > 20 else width
            lines.append(raw[:cut])
            raw = raw[cut:].lstrip()
        lines.append(raw)
    return lines


def build_report_lines(alerts: list[dict], summary: dict) -> list[tuple[str, str]]:
    """(style, text) pairs: style is 'h1', 'h2' or 'p'."""
    out = [("h1", "Network Intrusion Detection - Incident Report"),
           ("p", f"Generated: {_fmt(time.time())}    Alerts in report: {len(alerts)}"), ("p", "")]
    out.append(("h2", "Summary by severity"))
    for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"):
        out.append(("p", f"  {sev:<9}{summary.get('severity', {}).get(sev, 0)}"))
    out.append(("p", f"  Open (not resolved): {summary.get('open', 0)}"))
    out += [("p", ""), ("h2", "Top detections")]
    for r in summary.get("top_rules", [])[:8]:
        out.append(("p", f"  {r['n']:>5}  {r['name']} ({r['rule_id']})"))
    out += [("p", ""), ("h2", "Alert details")]
    for a in alerts:
        conf = f"{a['confidence']:.0%}" if a.get("confidence") is not None else "n/a"
        out.append(("p", f"#{a['id']} [{a['severity']}] {a['name']} ({a['rule_id']})"))
        out.append(("p", f"    {_fmt(a['ts'])}  {a['src']}:{a.get('sport', 0)} -> {a['dst']}:{a.get('dport', 0)}"
                         f"  {a.get('protocol', '')}  confidence {conf}  status {a['status']}"))
        out += [("p", "    " + line) for line in _wrap(a.get("description", ""), PDF_MAX_CHARS - 4)]
        if a.get("mitre"):
            out.append(("p", f"    MITRE ATT&CK: {a['mitre']}"))
        for n in a.get("notes", []) or []:
            out += [("p", "    Note: " + line) for line in _wrap(f"{n['by']}: {n['text']}", PDF_MAX_CHARS - 10)]
        out.append(("p", ""))
    return out


def to_pdf(alerts: list[dict], summary: dict) -> bytes:
    """Minimal multi-page text PDF (Helvetica) - no third-party library required."""
    lines = []
    for style, text in build_report_lines(alerts, summary):
        lines += [(style, part) for part in _wrap(text)]
    per_page = (PDF_PAGE_H - 2 * PDF_MARGIN) // PDF_LINE
    pages = [lines[i:i + per_page] for i in range(0, len(lines), per_page)] or [[]]
    objects: list[bytes] = []                      # object N is objects[N-1]
    page_ids = [4 + 2 * i for i in range(len(pages))]
    objects.append(b"<< /Type /Catalog /Pages 2 0 R >>")
    kids = " ".join(f"{pid} 0 R" for pid in page_ids)
    objects.append(f"<< /Type /Pages /Kids [{kids}] /Count {len(pages)} >>".encode())
    objects.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
    for number, page in enumerate(pages, 1):
        stream = ["BT"]
        y = PDF_PAGE_H - PDF_MARGIN
        for style, text in page:
            size = {"h1": 16, "h2": 12}.get(style, 9)
            stream.append(f"/F1 {size} Tf 1 0 0 1 {PDF_MARGIN} {y} Tm ({_pdf_escape(text)}) Tj")
            y -= PDF_LINE + (4 if style != "p" else 0)
        stream.append(f"/F1 8 Tf 1 0 0 1 {PDF_PAGE_W - 90} 20 Tm (Page {number}/{len(pages)}) Tj ET")
        body = "\n".join(stream).encode("latin-1", "replace")
        pid = page_ids[number - 1]
        objects.append(f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {PDF_PAGE_W} {PDF_PAGE_H}] "
                       f"/Resources << /Font << /F1 3 0 R >> >> /Contents {pid + 1} 0 R >>".encode())
        objects.append(b"<< /Length " + str(len(body)).encode() + b" >>\nstream\n" + body + b"\nendstream")
    out = bytearray(b"%PDF-1.4\n")
    offsets = []
    for i, obj in enumerate(objects, 1):
        offsets.append(len(out))
        out += f"{i} 0 obj\n".encode() + obj + b"\nendobj\n"
    xref = len(out)
    out += f"xref\n0 {len(objects) + 1}\n0000000000 65535 f \n".encode()
    for off in offsets:
        out += f"{off:010d} 00000 n \n".encode()
    out += f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF".encode()
    return bytes(out)
