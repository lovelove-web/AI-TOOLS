"""Protocol identification (by content, not just port) and metadata extraction."""
from __future__ import annotations

import re

from .constants import HTTP_METHODS, STANDARD_PORTS
from .packets import PacketInfo

HOST_RE = re.compile(rb"\r\nHost:\s*([^\r\n]+)", re.I)
UA_RE = re.compile(rb"\r\nUser-Agent:\s*([^\r\n]+)", re.I)
SNI_MARKER = b"\x00\x00"


def _tls_sni(p: bytes) -> str:
    """Very small ClientHello SNI parser."""
    try:
        pos = 43                                  # record(5)+hs(4)+ver(2)+random(32)
        pos += 1 + p[pos]                         # session id
        pos += 2 + int.from_bytes(p[pos:pos + 2], "big")   # cipher suites
        pos += 1 + p[pos]                         # compression
        end = pos + 2 + int.from_bytes(p[pos:pos + 2], "big")
        pos += 2
        while pos + 4 <= end:
            etype = int.from_bytes(p[pos:pos + 2], "big")
            elen = int.from_bytes(p[pos + 2:pos + 4], "big")
            if etype == 0:
                nlen = int.from_bytes(p[pos + 7:pos + 9], "big")
                return p[pos + 9:pos + 9 + nlen].decode(errors="replace")
            pos += 4 + elen
    except (IndexError, ValueError):
        pass
    return ""


def identify(pkt: PacketInfo) -> str:
    """Set and return the application protocol using DPI, falling back to ports."""
    p = pkt.payload
    proto = "UNKNOWN"
    if "dns_qname" in pkt.meta:
        proto = "DNS"
    elif p.startswith(HTTP_METHODS) or p.startswith(b"HTTP/1."):
        proto = "HTTP"
        m = HOST_RE.search(p)
        if m:
            pkt.meta["http_host"] = m.group(1).decode(errors="replace")
        u = UA_RE.search(p)
        if u:
            pkt.meta["http_ua"] = u.group(1).decode(errors="replace")
        if p.startswith(HTTP_METHODS):
            request_line = p.split(b"\r\n", 1)[0]
            method, _, rest = request_line.partition(b" ")
            # the URI may contain raw spaces (attack payloads): cut at the trailing HTTP version
            uri = rest.rsplit(b" HTTP/", 1)[0]
            pkt.meta["http_method"] = method.decode()
            pkt.meta["http_uri"] = uri.decode(errors="replace")
            pkt.meta["http_body"] = p.split(b"\r\n\r\n", 1)[1].decode(errors="replace") if b"\r\n\r\n" in p else ""
    elif p[:3] == b"\x16\x03\x01" or p[:2] == b"\x16\x03":
        proto = "TLS"
        if len(p) > 6 and p[5] == 1:
            pkt.meta["tls_sni"] = _tls_sni(p)
    elif p.startswith(b"SSH-"):
        proto = "SSH"
        pkt.meta["ssh_banner"] = p.split(b"\r\n")[0].decode(errors="replace")
    elif p[:4] in (b"\xffSMB", b"\xfeSMB") or p[4:8] in (b"\xffSMB", b"\xfeSMB"):
        proto = "SMB"
    elif p[:3] in (b"220", b"250", b"EHL", b"HEL") or p.startswith((b"MAIL FROM", b"RCPT TO")):
        proto = "SMTP"
    elif p.startswith((b"USER ", b"PASS ", b"STOR ", b"RETR ")) or p.startswith(b"220 ") and b"FTP" in p[:60]:
        proto = "FTP"
    elif pkt.is_udp and pkt.dport in (67, 68) and len(p) > 240 and p[236:240] == b"\x63\x82\x53\x63":
        proto = "DHCP"
    elif p[:1] in (b"\x10", b"\x30") and b"MQTT" in p[:12]:
        proto = "MQTT"
    elif p[:3] == b"\x03\x00\x00":
        proto = "RDP"
    pkt.l7 = proto
    return proto


def is_nonstandard_port(pkt: PacketInfo) -> bool:
    if pkt.l7 == "UNKNOWN" or pkt.l7 not in STANDARD_PORTS:
        return False
    ports = STANDARD_PORTS[pkt.l7]
    return pkt.dport not in ports and pkt.sport not in ports
