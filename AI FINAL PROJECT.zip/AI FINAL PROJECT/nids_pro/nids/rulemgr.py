"""Rule / signature / threshold management with persistence (dashboard-driven tuning)."""
from __future__ import annotations

import re
import threading

from .constants import DEFAULT_THRESHOLDS, MAX_CUSTOM_PATTERN, Severity
from .detect.signatures import Rule, SignatureDetector


class RuleManager:
    """Runtime overrides for rules, detectors and thresholds, persisted in SQLite."""

    def __init__(self, db, detectors, cfg):
        self.db, self.detectors, self.cfg = db, detectors, cfg
        self._lock = threading.Lock()
        self.disabled: set[str] = set()
        self.severity: dict[str, Severity] = {}
        self.sig = next(d for d in detectors if isinstance(d, SignatureDetector))
        self._load()

    # ------------------------------------------------------------- persistence
    def _load(self) -> None:
        for r in self.db.query("SELECT * FROM rule_overrides"):
            if not r["enabled"]:
                self.disabled.add(r["rule_id"])
            if r["severity"]:
                self.severity[r["rule_id"]] = Severity[r["severity"]]
        for r in self.db.query("SELECT * FROM custom_rules"):
            self._install(r)
        for r in self.db.query("SELECT * FROM threshold_overrides"):
            if r["key"] in DEFAULT_THRESHOLDS:
                self.cfg.thresholds[r["key"]] = self._cast(r["key"], r["value"])

    def _install(self, r: dict) -> None:
        self.sig.rules = [x for x in self.sig.rules if x.rule_id != r["rule_id"]]
        self.sig.rules.append(Rule(r["rule_id"], r["name"], r["category"] or "custom",
                                   Severity[r["severity"]], re.compile(r["pattern"], re.S),
                                   r["mitre"] or "", r["target"] or "payload"))

    @staticmethod
    def _cast(key: str, value: float):
        default = DEFAULT_THRESHOLDS[key]
        if isinstance(default, bool):
            return bool(value)
        return int(value) if isinstance(default, int) else float(value)

    # --------------------------------------------------------------- queries
    def list_rules(self) -> list[dict]:
        rows = [{"rule_id": r.rule_id, "name": r.name, "category": r.category,
                 "severity": self.effective_severity(r.rule_id, r.severity).name, "mitre": r.mitre,
                 "enabled": r.rule_id not in self.disabled, "custom": r.rule_id.startswith("CUS-"),
                 "pattern": r.pattern.pattern[:160]} for r in self.sig.rules]
        return sorted(rows, key=lambda x: x["rule_id"])

    def list_detectors(self) -> list[dict]:
        return [{"name": d.name, "enabled": d.enabled} for d in self.detectors]

    def list_thresholds(self) -> list[dict]:
        return [{"key": k, "value": self.cfg.thresholds[k], "default": v}
                for k, v in DEFAULT_THRESHOLDS.items()]

    def is_disabled(self, rule_id: str) -> bool:
        return rule_id in self.disabled

    def effective_severity(self, rule_id: str, default: Severity) -> Severity:
        return self.severity.get(rule_id, default)


    # --------------------------------------------------------------- mutations
    def set_rule(self, rule_id: str, enabled: bool | None, severity: str | None) -> None:
        with self._lock:
            if severity is not None:
                self.severity[rule_id] = Severity[severity]
            if enabled is not None:
                (self.disabled.discard if enabled else self.disabled.add)(rule_id)
            self.db.execute(
                "INSERT INTO rule_overrides (rule_id, enabled, severity, updated_at)"
                " VALUES (?,?,?,strftime('%s','now'))"
                " ON CONFLICT(rule_id) DO UPDATE SET enabled=excluded.enabled,"
                " severity=excluded.severity, updated_at=excluded.updated_at",
                (rule_id, 0 if rule_id in self.disabled else 1,
                 self.severity[rule_id].name if rule_id in self.severity else None))

    def set_detector(self, name: str, enabled: bool) -> None:
        for d in self.detectors:
            if d.name == name:
                d.enabled = enabled
                return
        raise KeyError(name)

    def set_threshold(self, key: str, value: float) -> None:
        if key not in DEFAULT_THRESHOLDS:
            raise KeyError(key)
        if value < 0:
            raise ValueError("threshold must be >= 0")
        with self._lock:
            self.cfg.thresholds[key] = self._cast(key, value)
            self.db.execute("INSERT INTO threshold_overrides (key, value) VALUES (?,?)"
                            " ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))

    def reset_threshold(self, key: str) -> None:
        if key not in DEFAULT_THRESHOLDS:
            raise KeyError(key)
        self.cfg.thresholds[key] = DEFAULT_THRESHOLDS[key]
        self.db.execute("DELETE FROM threshold_overrides WHERE key=?", (key,))

    def add_custom(self, rule_id: str, name: str, pattern: str, severity: str, target: str,
                   category: str = "custom") -> None:
        if not re.fullmatch(r"CUS-[A-Za-z0-9_-]{1,20}", rule_id):
            raise ValueError("rule_id must look like CUS-001")
        if len(pattern) > MAX_CUSTOM_PATTERN:
            raise ValueError(f"pattern longer than {MAX_CUSTOM_PATTERN} characters")
        re.compile(pattern)                       # raises re.error on an invalid regex
        if target not in ("http", "payload"):
            raise ValueError("target must be 'http' or 'payload'")
        Severity[severity]                        # validates the name
        row = {"rule_id": rule_id, "name": name[:80], "category": category[:30], "severity": severity,
               "pattern": pattern, "target": target, "mitre": ""}
        self.db.execute("INSERT OR REPLACE INTO custom_rules (rule_id, name, category, severity,"
                        " pattern, target, mitre) VALUES (:rule_id,:name,:category,:severity,"
                        ":pattern,:target,:mitre)", row)
        self._install(row)

    def delete_custom(self, rule_id: str) -> None:
        if not rule_id.startswith("CUS-"):
            raise ValueError("only custom rules can be deleted")
        self.db.execute("DELETE FROM custom_rules WHERE rule_id=?", (rule_id,))
        self.sig.rules = [r for r in self.sig.rules if r.rule_id != rule_id]
