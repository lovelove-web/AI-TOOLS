"""Processing pipeline: capture -> queue -> worker (decode, identify, log, detect) -> alert -> respond."""
from __future__ import annotations

import queue
import threading
import time

from scapy.all import PcapWriter

from . import protocols
from .alerts import Alert, AlertManager
from .capture import Capture
from .config import Config
from .constants import (CAPTURE_QUEUE_SIZE, FILE_COMMANDS, HEARTBEAT_INTERVAL,
                        HOUSEKEEPING_INTERVAL, PRIVILEGED_PORT_MAX, RELATED_PACKETS, SERVICE_PROTOS,
                        SYN, Severity)
from .detect import build_detectors
from .intel import ThreatIntel
from .notify import Notifier, console_sink
from .packets import PacketInfo, decode
from .response import ResponseEngine
from .rulemgr import RuleManager
from .stats import TrafficStats
from .storage import Database, JsonLogs

LOG_STREAM = {"DNS": "dns", "HTTP": "http", "TLS": "tls", "SSH": "ssh", "SMTP": "smtp",
              "FTP": "ftp", "SMB": "smb", "DHCP": "dhcp", "MQTT": "mqtt"}


class Engine:
    def __init__(self, cfg: Config, quiet: bool = False):
        self.cfg = cfg
        self.db = Database(cfg.db_file)
        self.logs = JsonLogs(cfg.log_dir)
        self.intel = ThreatIntel(cfg.threat_intel_files)
        self.detectors = build_detectors(cfg, self.db, self.intel)
        self.rules = RuleManager(self.db, self.detectors, cfg)
        self.response = ResponseEngine(cfg, self.db, self.intel)
        self.stats = TrafficStats()
        sinks = [self._persist, self.response.handle]
        if not quiet:
            sinks.insert(0, console_sink)
        if cfg.notifications:
            sinks.append(Notifier(cfg.notifications, Severity[cfg.min_notify_severity]))
        self.alerts = AlertManager(sinks, on_repeat=self._bump_count)
        self.capture: Capture | None = None
        self.active_interfaces: list[str] = list(cfg.interfaces)
        self.queue: queue.Queue = queue.Queue(maxsize=CAPTURE_QUEUE_SIZE)
        self.captured = self.dropped = self.packets = 0
        self.started = time.time()
        self.last_heartbeat = self.started
        self.last_error = ""
        self._last_house = time.time()
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self._worker: threading.Thread | None = None
        self._ignore, self._monitored = set(cfg.ignore_ips), set(cfg.monitored_ips)
        self._evidence = PcapWriter(f"{cfg.log_dir}/evidence.pcap", append=True, sync=True) \
            if cfg.pcap_evidence else None
        self._full = PcapWriter(cfg.pcap_all, append=True, sync=True) if cfg.pcap_all else None
        self._seen_assets: set[tuple] = set()

    # ------------------------------------------------------------- alert sinks
    def _persist(self, alert: Alert) -> None:
        alert.details["related"] = self.stats.related(alert.src, alert.dst, alert.ts, RELATED_PACKETS)
        self.db.save_alert(alert)
        self.logs.write("alerts", alert.to_dict())
        if self._evidence and alert.packet is not None:
            self._evidence.write(alert.packet)

    def _bump_count(self, alert: Alert) -> None:
        if alert.db_id is not None:
            self.db.execute("UPDATE alerts SET count=? WHERE id=?", (alert.count, alert.db_id))

    # ---------------------------------------------------------------- capture
    def enqueue(self, raw) -> None:
        """Sniffer callback: never blocks; counts drops when the worker falls behind."""
        self.captured += 1
        try:
            self.queue.put_nowait(raw)
        except queue.Full:
            self.dropped += 1

    def start_worker(self) -> None:
        if self._worker is None or not self._worker.is_alive():
            self._stop.clear()
            self._worker = threading.Thread(target=self._work, name="nids-worker", daemon=True)
            self._worker.start()

    def start_monitoring(self, interfaces: list[str] | None = None) -> None:
        with self._lock:
            if self.capture and self.capture.running:
                raise RuntimeError("monitoring is already running")
            self.active_interfaces = list(interfaces or self.cfg.interfaces)
            self.start_worker()
            capture = Capture(self.active_interfaces, self.cfg.bpf_filter, self.enqueue)
            try:
                capture.start()
            except Exception as exc:
                self.last_error = str(exc)
                raise
            self.capture, self.last_error = capture, ""

    def stop_monitoring(self) -> None:
        with self._lock:
            if self.capture:
                self.capture.stop()

    @property
    def monitoring(self) -> bool:
        return bool(self.capture and self.capture.running)

    def _work(self) -> None:
        while not self._stop.is_set():
            try:
                raw = self.queue.get(timeout=1)
            except queue.Empty:
                raw = None
            if raw is not None:
                self.handle_packet(raw)
            self._tick()

    def _tick(self) -> None:
        now = time.time()
        if now - self.last_heartbeat >= HEARTBEAT_INTERVAL:
            self.last_heartbeat = now
            flows = sum(len(getattr(d, "flows", ())) for d in self.detectors)
            self.db.execute("INSERT INTO health VALUES (?,?,?,?,?)",
                            (now, self.packets, self.alerts.total, flows, self.dropped))
        if now - self._last_house >= HOUSEKEEPING_INTERVAL:
            self._last_house = now
            for det in self.detectors:
                det.housekeeping(now)

    # --------------------------------------------------------------- pipeline
    def handle_packet(self, raw) -> None:
        if self._full:
            self._full.write(raw)
        p = decode(raw)
        if p is None or p.src in self._ignore:
            return
        if self._monitored and not {p.src, p.dst} & self._monitored:
            return
        self.packets += 1
        if not p.is_arp:
            protocols.identify(p)
            self._log_metadata(p)
        self.stats.add(p)
        self._track_asset(p)
        for det in self.detectors:
            if not det.enabled:
                continue
            try:
                for alert in det.process(p):
                    self._admit(alert)
            except Exception as exc:    # one buggy detector must not kill the sensor
                print(f"[!] detector {det.name} error: {exc!r}")

    def _admit(self, alert: Alert) -> None:
        """Apply analyst tuning (disabled rules, severity overrides) before alerting."""
        if self.rules.is_disabled(alert.rule_id):
            return
        alert.severity = self.rules.effective_severity(alert.rule_id, alert.severity)
        self.alerts.raise_alert(alert)

    def _log_metadata(self, p: PacketInfo) -> None:
        stream = LOG_STREAM.get(p.l7)
        if stream:
            self.logs.write(stream, {"src": p.src, "sport": p.sport, "dst": p.dst, "dport": p.dport,
                                     **{k: v for k, v in p.meta.items() if k != "http_body"}})
        if p.l7 == "FTP" and p.payload.startswith(FILE_COMMANDS):
            self.logs.write("files", {"src": p.src, "dst": p.dst, "protocol": "FTP",
                                      "command": p.payload[:120].decode(errors="replace").strip()})
        if p.is_tcp and p.flags & 0x3F == SYN:
            self.logs.write("flows", {"src": p.src, "sport": p.sport, "dst": p.dst,
                                      "dport": p.dport, "proto": "tcp", "ts": p.ts})

    def _track_asset(self, p: PacketInfo) -> None:
        if not p.src_mac:
            return
        service = p.l7 if p.l7 in SERVICE_PROTOS and p.sport < PRIVILEGED_PORT_MAX else None
        key = (p.src, service)
        if key not in self._seen_assets:
            self._seen_assets.add(key)
            self.db.upsert_asset(p.src, p.src_mac, service)

    # -------------------------------------------------------------- lifecycle
    def drain(self, timeout: float = 5.0) -> None:
        """Wait until queued packets are processed (used after replay and in tests)."""
        end = time.time() + timeout
        while not self.queue.empty() and time.time() < end:
            time.sleep(0.05)

    def wait_forever(self) -> None:
        try:
            while not self._stop.wait(1):
                pass
        except KeyboardInterrupt:
            pass

    def run_live(self) -> None:
        self.start_monitoring()
        self.wait_forever()

    def replay(self, pcap: str) -> None:
        Capture.replay(pcap, self.handle_packet)

    def health(self) -> dict:
        now = time.time()
        return {
            "monitoring": self.monitoring, "mode": self.cfg.mode, "interfaces": self.active_interfaces,
            "uptime": now - self.started, "packets_captured": self.captured,
            "packets_analysed": self.packets, "packets_dropped": self.dropped,
            "drop_rate": (self.dropped / self.captured) if self.captured else 0.0,
            "queue_depth": self.queue.qsize(), "queue_capacity": CAPTURE_QUEUE_SIZE,
            "worker_alive": bool(self._worker and self._worker.is_alive()),
            "last_heartbeat": self.last_heartbeat, "heartbeat_age": now - self.last_heartbeat,
            "alerts_total": self.alerts.total, "alerts_suppressed": self.alerts.suppressed,
            "detectors_enabled": sum(d.enabled for d in self.detectors),
            "detectors_total": len(self.detectors), "ml_loaded": any(
                getattr(d, "available", False) for d in self.detectors),
            "threat_intel_entries": len(self.intel), "last_error": self.last_error,
        }

    def stop(self) -> None:
        self.stop_monitoring()
        self.drain(2.0)
        self._stop.set()
        self.summary()
        for w in (self._evidence, self._full):
            if w:
                w.close()
        self.db.close()

    def summary(self) -> None:
        print("\n" + "=" * 70)
        print(f" NIDS SUMMARY  mode={self.cfg.mode.upper()}")
        print("=" * 70)
        print(f" Runtime          : {time.time() - self.started:.1f}s")
        print(f" Packets analysed : {self.packets} (dropped: {self.dropped})")
        print(f" Alerts raised    : {self.alerts.total} (duplicates suppressed: {self.alerts.suppressed})")
        print(f" Database / logs  : {self.cfg.db_file} / {self.cfg.log_dir}")
        print("=" * 70)
