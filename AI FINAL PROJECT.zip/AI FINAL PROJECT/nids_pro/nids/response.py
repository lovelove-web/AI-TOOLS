"""Active response: IDS (alert-only) or IPS (queued blocks needing analyst approval)."""
from __future__ import annotations

import ipaddress
import platform
import subprocess
import time
from collections import defaultdict, deque

from .alerts import Alert
from .constants import Severity

AUTO_BLOCK_MIN = Severity.HIGH
RATE_LIMIT_PER_MIN = 3     # max block proposals per source per minute


def firewall_command(ip: str, block: bool = True) -> list[str]:
    """OS-specific firewall command (Windows netsh / Linux iptables)."""
    ipaddress.ip_address(ip)                      # validates -> no command injection
    name = f"NIDS-block-{ip}"
    if platform.system() == "Windows":
        if block:
            return ["netsh", "advfirewall", "firewall", "add", "rule", f"name={name}",
                    "dir=in", "action=block", f"remoteip={ip}"]
        return ["netsh", "advfirewall", "firewall", "delete", "rule", f"name={name}"]
    return ["iptables", "-I" if block else "-D", "INPUT", "-s", ip, "-j", "DROP"]


class ResponseEngine:
    def __init__(self, cfg, db, intel=None):
        self.cfg, self.db, self.intel = cfg, db, intel
        self.never = {str(ipaddress.ip_address(i)) for i in cfg.never_block}
        self.recent = defaultdict(deque)

    def handle(self, alert: Alert) -> None:
        """Alert sink. In IDS mode does nothing; in IPS mode queues a block for approval."""
        if self.cfg.mode != "ips" or alert.severity < AUTO_BLOCK_MIN:
            return
        ip = alert.src
        try:
            addr = ipaddress.ip_address(ip)
        except ValueError:
            return
        if ip in self.never or addr.is_loopback or addr.is_multicast:
            return
        now = time.time()
        q = self.recent[ip]
        q.append(now)
        while q and now - q[0] > 60:
            q.popleft()
        if len(q) > RATE_LIMIT_PER_MIN:
            return
        pending = self.db.query("SELECT id FROM actions WHERE ip=? AND status IN ('pending','approved')", (ip,))
        if pending:
            return
        self.db.execute("INSERT INTO actions (ts, ip, action, reason) VALUES (?,?,?,?)",
                        (now, ip, "block", f"{alert.name} ({alert.rule_id})"))
        self.db.audit("system", "block_proposed", f"{ip}: {alert.name}")
        print(f"[IPS] Block of {ip} queued for analyst approval (reason: {alert.name})")

    def decide(self, action_id: int, approve: bool, actor: str, execute: bool = True) -> str:
        rows = self.db.query("SELECT * FROM actions WHERE id=?", (action_id,))
        if not rows or rows[0]["status"] != "pending":
            return "not found or already decided"
        ip = rows[0]["ip"]
        status = "approved" if approve else "rejected"
        self.db.execute("UPDATE actions SET status=?, decided_by=? WHERE id=?", (status, actor, action_id))
        self.db.audit(actor, f"block_{status}", ip)
        if approve and execute:
            result = subprocess.run(firewall_command(ip), capture_output=True, text=True, check=False)
            self.db.audit(actor, "firewall_executed", f"{ip} rc={result.returncode} {result.stderr[:100]}")
            return f"{status}; firewall rc={result.returncode}"
        return status

    def release(self, ip: str, actor: str) -> str:
        """Remove a block (quarantine release)."""
        result = subprocess.run(firewall_command(ip, block=False), capture_output=True, text=True, check=False)
        self.db.execute("UPDATE actions SET status='released' WHERE ip=? AND status='approved'", (ip,))
        self.db.audit(actor, "block_released", ip)
        return f"rc={result.returncode}"
