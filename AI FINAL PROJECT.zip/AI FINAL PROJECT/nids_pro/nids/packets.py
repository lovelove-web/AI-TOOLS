"""Packet decoding into a light-weight, scapy-independent structure."""
from __future__ import annotations

import ipaddress
import math
import time
from collections import Counter
from dataclasses import dataclass, field

from scapy.all import ARP, DNS, DNSQR, ICMP, IP, TCP, UDP, Ether, Raw

from .constants import (ACK, FIN, IP_PROTO_ICMP, IP_PROTO_TCP, IP_PROTO_UDP, PAYLOAD_PREVIEW_BYTES,
                        PROTO_NAMES, PSH, RST, SYN, URG)

FLAG_BITS = (("FIN", FIN), ("SYN", SYN), ("RST", RST), ("PSH", PSH), ("ACK", ACK), ("URG", URG))


def flags_to_str(flags: int) -> str:
    return "+".join(name for name, bit in FLAG_BITS if flags & bit) or "NONE"


@dataclass
class PacketInfo:
    ts: float
    src: str
    dst: str
    proto: int                 # IP protocol number, 0 for ARP
    sport: int = 0
    dport: int = 0
    flags: int = 0
    length: int = 0
    payload: bytes = b""
    icmp_type: int = -1
    frag_offset: int = 0
    more_frags: bool = False
    is_arp: bool = False
    src_mac: str = ""
    dst_mac: str = ""
    l7: str = "UNKNOWN"
    meta: dict = field(default_factory=dict)
    raw: object = None         # original scapy packet (for PCAP evidence)

    @property
    def is_tcp(self): return self.proto == IP_PROTO_TCP
    @property
    def is_udp(self): return self.proto == IP_PROTO_UDP
    @property
    def is_icmp(self): return self.proto == IP_PROTO_ICMP

    @property
    def proto_name(self) -> str:
        return "ARP" if self.is_arp else PROTO_NAMES.get(self.proto, f"IP/{self.proto}")

    def label(self) -> str:
        """Transport/application label, e.g. 'TCP/HTTP'."""
        return self.proto_name if self.l7 == "UNKNOWN" else f"{self.proto_name}/{self.l7}"

    def describe(self) -> dict:
        """JSON-safe packet summary used for drill-down and evidence."""
        shown = self.payload[:PAYLOAD_PREVIEW_BYTES]
        meta = {k: (v[:200] if isinstance(v, str) else v) for k, v in self.meta.items()}
        return {
            "ts": self.ts, "src": self.src, "dst": self.dst, "sport": self.sport, "dport": self.dport,
            "protocol": self.proto_name, "app_protocol": self.l7,
            "tcp_flags": flags_to_str(self.flags) if self.is_tcp else "",
            "length": self.length, "src_mac": self.src_mac, "dst_mac": self.dst_mac,
            "icmp_type": self.icmp_type if self.is_icmp else None,
            "fragment": bool(self.frag_offset or self.more_frags), "metadata": meta,
            "payload_hex": shown.hex(" "),
            "payload_ascii": "".join(chr(b) if 32 <= b < 127 else "." for b in shown),
        }


def is_private(ip: str) -> bool:
    """Wrapper over the stdlib so we never re-implement RFC1918 logic."""
    try:
        return ipaddress.ip_address(ip).is_private
    except ValueError:
        return False


def ip_to_number(ip: str) -> float:
    try:
        return float(int(ipaddress.IPv4Address(ip)))
    except ValueError:
        return 0.0


def shannon_entropy(values) -> float:
    values = list(values)
    if not values:
        return 0.0
    counts = Counter(values)
    n = len(values)
    return -sum(c / n * math.log2(c / n) for c in counts.values())


def decode(pkt) -> PacketInfo | None:
    ts = float(getattr(pkt, "time", time.time()))
    mac_src = pkt[Ether].src if Ether in pkt else ""
    mac_dst = pkt[Ether].dst if Ether in pkt else ""
    if ARP in pkt:
        a = pkt[ARP]
        return PacketInfo(ts, a.psrc, a.pdst, 0, is_arp=True, src_mac=a.hwsrc or mac_src,
                          dst_mac=mac_dst, length=len(pkt), flags=int(a.op), raw=pkt)
    if IP not in pkt:
        return None
    ip = pkt[IP]
    info = PacketInfo(ts, ip.src, ip.dst, int(ip.proto), length=int(ip.len or len(pkt)),
                      frag_offset=int(ip.frag), more_frags=bool(int(ip.flags) & 0x1),
                      src_mac=mac_src, dst_mac=mac_dst, raw=pkt)
    if TCP in pkt:
        t = pkt[TCP]
        info.sport, info.dport, info.flags = int(t.sport), int(t.dport), int(t.flags)
    elif UDP in pkt:
        u = pkt[UDP]
        info.sport, info.dport = int(u.sport), int(u.dport)
    elif ICMP in pkt:
        info.icmp_type = int(pkt[ICMP].type)
    if Raw in pkt:
        info.payload = bytes(pkt[Raw].load)
    if DNS in pkt and DNSQR in pkt:
        q = pkt[DNS]
        question = pkt[DNSQR]
        info.meta["dns_qname"] = question.qname.decode(errors="replace").rstrip(".")
        info.meta["dns_qtype"] = int(question.qtype)
        info.meta["dns_response"] = bool(q.qr)
    return info
