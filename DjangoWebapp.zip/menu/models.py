from django.db import models


class Dish(models.Model):
    CUISINE_CHOICES = [
        ("africa", "Africa"),
        ("asia", "Asia"),
        ("mexico", "Mexico"),
        ("finland", "Finland"),
        ("france", "France"),
    ]

    dish_id = models.CharField(max_length=10, unique=True)
    cuisine = models.CharField(max_length=20, choices=CUISINE_CHOICES)
    flag = models.CharField(max_length=10, blank=True)
    name = models.CharField(max_length=200)
    description = models.TextField()
    price = models.DecimalField(max_digits=8, decimal_places=2)
    emoji = models.CharField(max_length=10, blank=True)
    available = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class Reservation(models.Model):
    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("confirmed", "Confirmed"),
        ("cancelled", "Cancelled"),
    ]

    name = models.CharField(max_length=100)
    guests = models.PositiveIntegerField()
    date = models.DateField()
    time = models.TimeField()
    email = models.EmailField(blank=True)
    note = models.TextField(blank=True)
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default="pending",
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.date} {self.time}"