import json
from datetime import datetime

import stripe
from django.conf import settings
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.http import require_POST

from .models import Dish, Reservation


stripe.api_key = settings.STRIPE_SECRET_KEY

DELIVERY_FEE = 3.50


def home(request):
    dishes = Dish.objects.filter(
        available=True
    ).order_by("cuisine", "name")

    return render(
        request,
        "menu/home.html",
        {"dishes": dishes},
    )


@require_POST
def create_checkout_session(request):
    try:
        data = json.loads(request.body)
        cart = data.get("cart", {})

        if not isinstance(cart, dict) or not cart:
            return JsonResponse(
                {"error": "Basket is empty."},
                status=400,
            )

        line_items = []

        for dish_id, qty in cart.items():
            if (
                not isinstance(dish_id, str)
                or not isinstance(qty, int)
                or isinstance(qty, bool)
                or qty <= 0
            ):
                continue

            dish = Dish.objects.filter(
                dish_id=dish_id,
                available=True,
            ).first()

            if not dish:
                continue

            line_items.append(
                {
                    "price_data": {
                        "currency": "usd",
                        "product_data": {
                            "name": dish.name
                        },
                        "unit_amount": int(dish.price * 100),
                    },
                    "quantity": qty,
                }
            )

        if not line_items:
            return JsonResponse(
                {"error": "No valid items in basket."},
                status=400,
            )

        line_items.append(
            {
                "price_data": {
                    "currency": "usd",
                    "product_data": {
                        "name": "Delivery"
                    },
                    "unit_amount": int(DELIVERY_FEE * 100),
                },
                "quantity": 1,
            }
        )

        session = stripe.checkout.Session.create(
            mode="payment",
            payment_method_types=["card"],
            line_items=line_items,
            success_url=(
                request.build_absolute_uri("/order/success/")
                + "?session_id={CHECKOUT_SESSION_ID}"
            ),
            cancel_url=request.build_absolute_uri(
                "/order/cancel/"
            ),
        )

        return JsonResponse({"url": session.url})

    except json.JSONDecodeError:
        return JsonResponse(
            {"error": "Invalid JSON request."},
            status=400,
        )

    except stripe.error.StripeError as e:
        return JsonResponse(
            {"error": str(e)},
            status=400,
        )


@require_POST
def create_reservation(request):
    name = request.POST.get("name", "").strip()
    guests = request.POST.get("guests", "").strip()
    date = request.POST.get("date", "").strip()
    time = request.POST.get("time", "").strip()
    email = request.POST.get("email", "").strip()
    note = request.POST.get("note", "").strip()

    if not name or not guests or not date or not time:
        return JsonResponse(
            {"error": "Please fill in all required fields."},
            status=400,
        )

    try:
        guests = int(guests)

        if guests < 1 or guests > 12:
            raise ValueError

    except ValueError:
        return JsonResponse(
            {"error": "Guests must be between 1 and 12."},
            status=400,
        )

    try:
        reservation_date = datetime.strptime(
            date,
            "%Y-%m-%d",
        ).date()

        reservation_time = datetime.strptime(
            time,
            "%H:%M",
        ).time()

    except ValueError:
        return JsonResponse(
            {"error": "Invalid date or time."},
            status=400,
        )

    Reservation.objects.create(
        name=name,
        guests=guests,
        date=reservation_date,
        time=reservation_time,
        email=email,
        note=note,
    )

    return JsonResponse(
        {
            "message": (
                f"Table requested for {name}!"
            )
        }
    )


def order_success(request):
    session_id = request.GET.get("session_id")
    session = None

    if session_id:
        try:
            session = stripe.checkout.Session.retrieve(
                session_id
            )
        except stripe.error.StripeError:
            pass

    return render(
        request,
        "menu/success.html",
        {"session": session},
    )


def order_cancel(request):
    return render(
        request,
        "menu/cancel.html",
    )
