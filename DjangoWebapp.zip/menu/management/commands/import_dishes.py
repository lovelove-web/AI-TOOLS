from django.core.management.base import BaseCommand
from menu.models import Dish


DISHES = [
    ("af1", "africa", "🇳🇬", "Jollof Rice & Grilled Chicken", "Smoky tomato rice, deep West-African spice, char-grilled chicken thigh.", 14.50, "🍛"),
    ("af2", "africa", "🇳🇬", "Suya Beef Skewers", "Peanut-spiced skewers, charcoal grilled, served with pickled onion.", 12.00, "🍢"),
    ("af3", "africa", "🇪🇹", "Injera with Doro Wat", "Sourdough flatbread with slow-braised berbere chicken stew.", 15.00, "🫓"),
    ("af4", "africa", "🇳🇬", "Chin Chin", "Crunchy fried pastry bites, lightly sweetened, cinnamon dusted.", 5.50, "🍩"),
    ("af5", "africa", "🇸🇳", "Bissap Hibiscus Cooler", "Chilled hibiscus & ginger infusion, mint garnish.", 4.00, "🥤"),

    ("as1", "asia", "🇹🇭", "Pad Thai", "Wok-tossed rice noodles, tamarind, peanuts, prawns or tofu.", 13.50, "🍜"),
    ("as2", "asia", "🇯🇵", "Sushi Sampler Platter", "Eight-piece nigiri & maki selection, wasabi and pickled ginger.", 18.00, "🍣"),
    ("as3", "asia", "🇯🇵", "Shoyu Ramen", "Soy-based broth, chashu pork, soft egg, scallion.", 14.00, "🍲"),
    ("as4", "asia", "🇹🇭", "Mango Sticky Rice", "Coconut sticky rice, ripe mango, toasted sesame.", 6.50, "🥭"),
    ("as5", "asia", "🇹🇭", "Thai Iced Tea", "Spiced black tea, condensed milk, over ice.", 4.50, "🧋"),

    ("mx1", "mexico", "🇲🇽", "Tacos al Pastor (3pc)", "Marinated pork, charred pineapple, cilantro, onion, corn tortilla.", 11.50, "🌮"),
    ("mx2", "mexico", "🇲🇽", "Street Corn Elote", "Grilled corn, chili-lime crema, cotija cheese.", 6.00, "🌽"),
    ("mx3", "mexico", "🇲🇽", "Chiles Rellenos", "Roasted poblano, melted cheese, tomato-ranchero sauce.", 13.00, "🌶️"),
    ("mx4", "mexico", "🇲🇽", "Churros & Chocolate", "Cinnamon-sugar churros, dark chocolate dip.", 6.50, "🍫"),
    ("mx5", "mexico", "🇲🇽", "Horchata", "Rice & cinnamon milk, chilled.", 4.00, "🥛"),

    ("fi1", "finland", "🇫🇮", "Karjalanpiirakka", "Karelian rye pies with rice filling, egg-butter topping.", 9.00, "🥧"),
    ("fi2", "finland", "🇫🇮", "Lohikeitto Salmon Soup", "Creamy salmon & potato soup, dill, rye bread.", 14.50, "🍜"),
    ("fi3", "finland", "🇫🇮", "Sautéed Reindeer", "Poronkäristys-style reindeer, lingonberry, mashed potato.", 19.00, "🦌"),
    ("fi4", "finland", "🇫🇮", "Cinnamon Pulla", "Cardamom-cinnamon sweet bread bun.", 4.50, "🥐"),
    ("fi5", "finland", "🇫🇮", "Glögi Mulled Berry Drink", "Warm spiced berry glögi, almonds & raisins.", 5.00, "🍷"),

    ("fr1", "france", "🇫🇷", "Coq au Vin", "Red wine braised chicken, mushroom, pearl onion.", 17.50, "🍗"),
    ("fr2", "france", "🇫🇷", "French Onion Soup", "Caramelised onion broth, gruyère crouton.", 9.50, "🍲"),
    ("fr3", "france", "🇫🇷", "Ratatouille", "Provençal stewed vegetables, herbs de Provence.", 12.00, "🍆"),
    ("fr4", "france", "🇫🇷", "Crème Brûlée", "Vanilla custard, brûléed sugar crust.", 7.00, "🍮"),
    ("fr5", "france", "🇫🇷", "Vin Chaud", "Warm mulled French red wine, orange & clove.", 5.50, "🍷"),
]


class Command(BaseCommand):
    help = "Import restaurant dishes"

    def handle(self, *args, **options):
        for dish_id, cuisine, flag, name, description, price, emoji in DISHES:
            Dish.objects.update_or_create(
                dish_id=dish_id,
                defaults={
                    "cuisine": cuisine,
                    "flag": flag,
                    "name": name,
                    "description": description,
                    "price": price,
                    "emoji": emoji,
                    "available": True,
                },
            )

        self.stdout.write(
            self.style.SUCCESS("25 dishes imported successfully.")
        )