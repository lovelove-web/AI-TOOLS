from django.contrib import admin
from .models import Dish, Reservation


@admin.register(Dish)
class DishAdmin(admin.ModelAdmin):
    list_display = (
        "dish_id",
        "name",
        "cuisine",
        "price",
        "available",
    )

    list_filter = (
        "cuisine",
        "available",
    )

    search_fields = (
        "dish_id",
        "name",
        "description",
    )

    ordering = (
        "cuisine",
        "name",
    )


@admin.register(Reservation)
class ReservationAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "date",
        "time",
        "guests",
        "email",
        "status",
        "created_at",
    )

    list_filter = (
        "status",
        "date",
    )

    search_fields = (
        "name",
        "email",
        "note",
    )

    ordering = (
        "-date",
        "-time",
    )